<?php
/**
 * Cobrinha block theme — enqueue the site styles and script, register the pattern category.
 */
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'cobrinha-fonts', 'https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Archivo:wght@400;500;600;700&display=swap', array(), null );
	wp_enqueue_style( 'cobrinha-site', get_template_directory_uri() . '/assets/css/site.css', array(), '1.0.0' );
	wp_enqueue_script( 'cobrinha-site', get_template_directory_uri() . '/assets/js/site.js', array(), '1.0.0', array( 'in_footer' => true, 'strategy' => 'defer' ) );
} );
add_action( 'init', function () {
	register_block_pattern_category( 'cobrinha', array( 'label' => 'Cobrinha' ) );
} );
add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/site.css' );
} );
// Site-wide meta the static prototype carried in the <head>.
add_action( 'wp_head', function () {
	echo '<meta name="theme-color" content="#0B0B0C">' . "\n";
	echo '<link rel="icon" href="' . esc_url( get_template_directory_uri() ) . '/assets/img/favicon.svg" type="image/svg+xml">' . "\n";
	echo '<script type="application/ld+json">{"@context":"https://schema.org","@type":"SportsActivityLocation","name":"Alliance Jiu Jitsu Los Angeles by Cobrinha","alternateName":"Cobrinha Brazilian Jiu-Jitsu & Fitness","telephone":"+1-323-931-9953","email":"info@cobrinhabjj.com","url":"https://www.cobrinhabjj.com/","address":{"@type":"PostalAddress","streetAddress":"4929 Wilshire Blvd #104","addressLocality":"Los Angeles","addressRegion":"CA","postalCode":"90010","addressCountry":"US"}}</script>' . "\n";
}, 5 );
// Pages the theme expects to exist. Created once on activation with the matching template.
add_action( 'init', function () {
	if ( get_option( 'cobrinha_pages_created' ) ) { return; }
	$pages = array( 'start' => 'Start here', 'kids' => 'Kids & teens', 'programs' => 'Programs', 'schedule' => 'Schedule', 'academy' => 'The academy', 'instructors' => 'Instructors', 'visit' => 'Visiting & parking', 'pricing' => 'Membership', 'faq' => 'Questions & answers', 'contact' => 'Contact', 'free-class' => 'Book a free class', 'privacy' => 'Privacy policy' );
	foreach ( $pages as $slug => $title ) {
		if ( ! get_page_by_path( $slug ) ) {
			$id = wp_insert_post( array( 'post_title' => $title, 'post_name' => $slug, 'post_type' => 'page', 'post_status' => 'publish', 'post_content' => '' ) );
			if ( $id ) { update_post_meta( $id, '_wp_page_template', 'page-' . $slug ); }
		}
	}
	if ( ! get_page_by_path( 'home' ) ) {
		$home = wp_insert_post( array( 'post_title' => 'Home', 'post_name' => 'home', 'post_type' => 'page', 'post_status' => 'publish', 'post_content' => '' ) );
		update_option( 'show_on_front', 'page' ); update_option( 'page_on_front', $home );
	}
	update_option( 'cobrinha_pages_created', 1 );
} );
