<?php
/**
 * Title: Jiu-Jitsu Brasileiro em Los Angeles
 * Slug: cobrinha/pt
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<header class="hero">
  <img class="hero-img" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/hero-mat.webp" alt="Cobrinha sentado à frente de um tatame cheio de alunos na academia de Los Angeles" fetchpriority="high">
  <div class="hero-in">
    <div class="hero-copy">
    <p class="eyebrow light">Jiu-Jitsu Brasileiro · Wilshire e Highland, Los Angeles</p>
    <h1 class="display">Treine com uma lenda.<br><span class="thin">Comece do zero.</span></h1>
    <p class="hero-badge">O único campeão do Super Grand Slam da história</p>
    <p class="lead">Dirigida por Rubens "Cobrinha" Charles, cinco vezes campeão mundial. Dezesseis anos na Wilshire. Sua primeira aula é grátis.</p>
    <div class="hero-actions">
      <a class="btn red big" href="/free-class/">Agendar aula grátis</a>
      <a class="btn ghost big" href="/schedule/">Ver horários</a>
    </div>
    <div class="chips">
      <span class="chip"><b>16</b> anos na Wilshire</span>
      <span class="chip"><b><span class="star">★</span> 4.9</b> no Google</span>
      <span class="chip"><b>5×</b> campeão mundial</span>
      <span class="chip"><b>Único</b> campeão do Super Grand Slam</span>
    </div>
    </div>
  </div>
</header>

<section class="dark proof">
  <div class="wrap proof-in">
    <div class="stat"><b><span data-count="16">0</span></b><span>Anos na Wilshire</span></div>
    <div class="stat"><b><span data-count="5">0</span><i>×</i></b><span>Campeão Mundial IBJJF</span></div>
    <div class="stat"><b><span data-count="3">0</span><i>×</i></b><span>Campeão ADCC</span></div>
    <div class="stat"><b><span data-count="4.9">0</span></b><span>Nota no Google, 200 avaliações</span></div>
    <div class="stat"><b>Único</b><span>Campeão do Super Grand Slam da história</span></div>
  </div>
</section>

<section class="mat">
  <div class="wrap">
    <div class="sec-head rv">
      <p class="eyebrow">Nunca treinou? Comece aqui.</p>
      <h2 class="display">Seu primeiro mês, passo a passo.</h2>
      <p class="lead">A maioria das pessoas que chega nunca fez arte marcial. O caminho é simples e ninguém cai na turma avançada.</p>
    </div>
    <div class="steps rv stagger">
      <div class="step"><h3>Agende uma aula grátis</h3><p>Escolha um horário e avise que você vem, para um professor estar esperando. Assine o termo online antes: é ele que cria o seu cadastro. Alugue um kimono na recepção ($20, devolvido na matrícula).</p><p class="when">Seg e Qua 20h · Qui 18h10</p></div>
      <div class="step"><h3>Curso de iniciantes de quatro semanas</h3><p>Três aulas por semana para quem não tem experiência: como cair, como levantar, como escapar, as primeiras finalizações. Ensinado por faixas pretas e marrons. Você pode começar em qualquer semana.</p><p class="when">Seg e Qua 20h · Qui 18h10</p></div>
      <div class="step"><h3>Entre no Fundamentos</h3><p>Depois do curso você passa para o Fundamentos 1 com pessoas do seu nível e vai ganhando graus até o Fundamentos 2 e a turma avançada.</p><p class="when">Todos os dias, manhã e noite</p></div>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="sec-head rv"><p class="eyebrow">Programas</p><h2 class="display">Uma turma para onde você está.</h2></div>
    <div class="prog rv stagger">
      <a class="pcard" href="/start/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/beginners.webp" alt="" loading="lazy"><div class="pin"><small>Adultos · sem experiência</small><b>Iniciantes</b><span>Curso de quatro semanas</span></div></a>
      <a class="pcard" href="/programs/#fundamentals"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-fundamentals.webp" alt="" loading="lazy"><div class="pin"><small>Adultos</small><b>Fundamentos</b><span>Níveis 1, 2 e 3</span></div></a>
      <a class="pcard" href="/programs/#nogi"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-nogi-1.webp" alt="" loading="lazy"><div class="pin"><small>Todos os níveis</small><b>No-Gi</b><span>Seis aulas por semana</span></div></a>
      <a class="pcard" href="/womens/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-womens-1.webp" alt="" loading="lazy"><div class="pin"><small>Só mulheres</small><b>Feminino</b><span>Professora faixa preta</span></div></a>
      <a class="pcard" href="/kids/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/kids-run.webp" alt="" loading="lazy"><div class="pin"><small>3 a 12 anos</small><b>Kids · Eagles</b><span>Quatro turmas por idade</span></div></a>
      <a class="pcard" href="/kids/#teens"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-kids-coach.webp" alt="" loading="lazy"><div class="pin"><small>13 a 16 anos</small><b>Adolescentes</b><span>Ter e Qui 17h</span></div></a>
      <a class="pcard" href="/programs/#advanced"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-nogi-win.webp" alt="" loading="lazy"><div class="pin"><small>Faixa azul em diante</small><b>Avançado e competição</b><span>A turma do Cobrinha</span></div></a>
      <a class="pcard" href="/programs/#private"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/cobrinha.webp" alt="" loading="lazy"><div class="pin"><small>Individual</small><b>Aulas particulares</b><span>Professores faixa preta e marrom</span></div></a>
    </div>
  </div>
</section>

<section class="mat">
  <div class="wrap split">
    <div class="media wide rv l"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/kids-run.webp" alt="Seis crianças de kimono correndo pelo tatame, rindo" loading="lazy"></div>
    <div class="rv r">
      <p class="eyebrow">Crianças e adolescentes · programa Eagles</p>
      <h2 class="display">Confiança que eles mesmos conquistam.</h2>
      <p class="lead">De 3 a 16 anos, separados por idade e nível. O Jiu-Jitsu é a arte marcial mais segura para começar: sem socos, sem chutes, e com uma técnica que permite ao menor controlar o maior.</p>
      <div class="strip">
        <div class="srow"><b>Baby Eagles · 3–4 anos</b><span>Ter e Qui 16h10 · experimental 15h30</span></div>
        <div class="srow"><b>Little Eagles · 5–6 anos</b><span>Seg, Qua e Sex 16h10 · experimental 15h30</span></div>
        <div class="srow"><b>Eagle Warriors · 7–12 anos</b><span>Seg a Qui 17h · Sáb 9h</span></div>
        <div class="srow"><b>Eagle Teens · 13–16 anos</b><span>Ter e Qui 17h</span></div>
      </div>
      <p class="small muted">A aula experimental é grátis e individual com um professor: agende antes. Aluguel de kimono $15, devolvido na matrícula. Desconto família a partir do segundo membro.</p>
      <a class="btn red" href="free-class.html?program=kids">Agendar experimental kids</a>
    </div>
  </div>
</section>

<section class="dark">
  <div class="wrap split rev">
    <div class="media tall rv r"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/cobrinha.webp" alt="Rubens Cobrinha Charles de kimono Alliance, braços cruzados, sorrindo" loading="lazy"></div>
    <div class="rv l">
      <p class="eyebrow light">Professor principal</p>
      <h2 class="display">Rubens "Cobrinha" Charles</h2>
      <p class="lead">O único faixa preta da história a vencer ADCC, Mundial, Pan-Americano, Europeu e Brasileiro no mesmo ano. Dá aula neste tatame toda semana, e dá aula para iniciantes.</p>
      <ul class="titles">
        <li><b>5×</b><span>Campeão Mundial IBJJF (2006–2009, 2017)</span></li>
        <li><b>4×</b><span>Campeão Mundial No-Gi IBJJF</span></li>
        <li><b>3×</b><span>Campeão Mundial ADCC (2013, 2015, 2017)</span></li>
        <li><b>HOF</b><span>Hall da Fama IBJJF e ADCC</span></li>
      </ul>
      <a class="btn ghost" href="/instructors/" style="margin-top:14px">Conheça os professores</a>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="sec-head rv"><p class="eyebrow">Mensalidade</p><h2 class="display">Uma mensalidade, a academia inteira.</h2><p class="lead">Faça uma aula grátis primeiro. As mensalidades renovam todo mês com 30 dias de aviso e incluem todos os programas e professores, seis dias por semana. A recepção explica os planos depois da primeira aula. Desconto família a partir do segundo membro.</p></div>
    <div class="plans rv up">
      <div class="plan"><p class="plan-name">Silver</p><p class="plan-what">8 aulas por mês</p></div>
      <div class="plan hot"><p class="plan-name">Gold</p><p class="plan-what">12 aulas por mês</p></div>
      <div class="plan"><p class="plan-name">Platinum</p><p class="plan-what">Aulas ilimitadas</p></div>
      <div class="plan"><p class="plan-name">Kids e adolescentes</p><p class="plan-what">As aulas da faixa etária</p></div>
    </div>
  </div>
</section>

<section class="mat">
  <div class="wrap">
    <div class="sec-head rv"><p class="eyebrow">Perguntas frequentes</p><h2 class="display">Respostas diretas.</h2></div>
    <div class="faq rv">
      <details><summary>Nunca fiz arte marcial. Vou ficar perdido?</summary><div class="ans">Não. Iniciantes começam num curso de quatro semanas feito para zero experiência e depois passam para o Fundamentos com pessoas do mesmo nível. Ninguém faz sparring na primeira aula sem pedir.</div></details>
      <details><summary>Quando é a aula experimental grátis?</summary><div class="ans">Adultos: qualquer segunda ou quarta às 20h, ou quinta às 18h10. Mulheres: quarta 18h10 (também terça ou quinta 18h10). Crianças de 3 a 6: 15h30 (30 minutos); de 7 a 12: segunda a quinta às 17h; adolescentes: terça ou quinta às 17h. Agende antes e assine o termo online.</div></details>
      <details><summary>O que eu visto?</summary><div class="ans">Roupa esportiva confortável. Alugue um kimono na recepção ($20 adultos, $15 crianças; devolvido na matrícula). Todo mundo treina de kimono azul ou branco Alliance ou Cobrinha: somos um time só.</div></details>
      <details><summary>Quanto custa?</summary><div class="ans">As mensalidades renovam todo mês, com 30 dias de aviso para cancelar, de 8 aulas por mês até ilimitado, com desconto família a partir do segundo membro. Faça uma aula grátis e a recepção explica as opções.</div></details>
      <details><summary>Onde estaciono?</summary><div class="ans">No estacionamento do prédio com validação: grátis antes das 8h30, depois das 18h e nos fins de semana; $5 por duas horas ao meio-dia. Vagas grátis na rua Highland.</div></details>
      <details><summary>Vocês falam português?</summary><div class="ans">Sim. Vários professores são brasileiros. Ligue ou mande mensagem para <a class="link" href="tel:+13239319953">(323) 931-9953</a>.</div></details>
    </div>
    <p class="rv" style="margin-top:22px"><a class="btn line" href="/">Read this page in English</a> <a class="btn line" href="/es/" lang="es" style="margin-left:8px">Leer en español</a></p>
  </div>
</section>

<!-- /wp:html -->
