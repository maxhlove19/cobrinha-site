<?php
/**
 * Title: Jiu-Jitsu Brasileiro em Los Angeles
 * Slug: cobrinha/pt
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<header class="hero">
  <img class="hero-img" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/hero-mat.webp" alt="Cobrinha sentado à frente de um tatame cheio de alunos na academia de Los Angeles" fetchpriority="high" width="1800" height="1013">
  <div class="hero-in">
    <div class="hero-copy">
    <p class="eyebrow light">Jiu-Jitsu Brasileiro · Wilshire e Highland, Los Angeles</p>
    <h1 class="display">Treine com uma lenda.<br><span class="thin">Comece do zero.</span></h1>
    <p class="hero-badge">O único campeão do Super Grand Slam da história</p>
    <p class="lead">Dirigida por Rubens "Cobrinha" Charles, cinco vezes campeão mundial. Na Wilshire há <span data-years>16</span> anos. Comece pelo curso para iniciantes de quatro semanas ou matricule-se direto.</p>
    <div class="hero-actions">
      <a class="btn red big" href="/start/">Comece a treinar</a>
      <a class="btn ghost big" href="/schedule/">Ver horários</a>
    </div>
    <div class="chips">
      <span class="chip"><b data-years>16</b> anos na Wilshire</span>
      <span class="chip"><b><span class="star">★</span> 4.9</b> no Google</span>
      <span class="chip"><b>5×</b> campeão mundial</span>
      <span class="chip"><b>Único</b> campeão do Super Grand Slam</span>
    </div>
    </div>
  </div>
</header>

<section class="dark proof">
  <div class="wrap proof-in">
    <div class="stat"><b><span data-years>16</span></b><span>Anos na Wilshire</span></div>
    <div class="stat"><b><span data-count="5">0</span><i>×</i></b><span>Campeão Mundial IBJJF</span></div>
    <div class="stat"><b><span data-count="3">0</span><i>×</i></b><span>Campeão ADCC</span></div>
    <div class="stat"><b><span data-count="4.9">0</span></b><span>Nota no Google, 200 avaliações</span></div>
    <div class="stat"><b>Único</b><span>Campeão do Super Grand Slam da história</span></div>
  </div>
</section>


<section>
  <div class="wrap">
    <div class="sec-head rv"><p class="eyebrow">Programas</p><h2 class="display">Uma turma para onde você está.</h2></div>
    <div class="prog rv stagger">
      <a class="pcard" href="/start/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/beginners.webp" alt="" loading="lazy" width="846" height="564"><div class="pin"><small>Adultos · sem experiência</small><b>Iniciantes</b><span>Curso de quatro semanas</span></div></a>
      <a class="pcard" href="/programs/#fundamentals"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-fundamentals.webp" alt="" loading="lazy" width="720" height="1280"><div class="pin"><small>Adultos</small><b>Fundamentos</b><span>Níveis 1, 2 e 3</span></div></a>
      <a class="pcard" href="/programs/#nogi"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-nogi-1.webp" alt="" loading="lazy" width="899" height="992"><div class="pin"><small>Todos os níveis</small><b>No-Gi</b><span>Seis aulas por semana</span></div></a>
      <a class="pcard" href="/womens/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-womens-1.webp" alt="" loading="lazy" width="640" height="665"><div class="pin"><small>Só mulheres</small><b>Feminino</b><span>Professora faixa preta</span></div></a>
      <a class="pcard" href="/kids/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/kids-run.webp" alt="" loading="lazy" width="1800" height="1200"><div class="pin"><small>3 a 12 anos</small><b>Kids · Eagles</b><span>Quatro turmas por idade</span></div></a>
      <a class="pcard" href="/kids/#teens"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-kids-coach.webp" alt="" loading="lazy" width="640" height="1136"><div class="pin"><small>13 a 16 anos</small><b>Adolescentes</b><span>Ter e Qui 17h</span></div></a>
      <a class="pcard" href="/programs/#advanced"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-nogi-win.webp" alt="" loading="lazy" width="901" height="1496"><div class="pin"><small>Faixa azul em diante</small><b>Avançado e competição</b><span>A turma do Cobrinha</span></div></a>
      <a class="pcard" href="/programs/#private"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/cobrinha.webp" alt="" loading="lazy" width="500" height="749"><div class="pin"><small>Individual</small><b>Aulas particulares</b><span>Professores faixa preta e marrom</span></div></a>
    </div>
  </div>
</section>


<section class="dark">
  <div class="wrap split rev">
    <div class="media tall rv r"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/cobrinha.webp" alt="Rubens Cobrinha Charles de kimono Alliance, braços cruzados, sorrindo" loading="lazy" width="500" height="749"></div>
    <div class="rv l">
      <p class="eyebrow light">Professor principal</p>
      <h2 class="display">Rubens "Cobrinha" Charles</h2>
      <p class="lead">O único faixa preta da história a vencer ADCC, Mundial, Pan-Americano, Europeu e Brasileiro no mesmo ano. Dá aula neste tatame toda semana, e dá aula para iniciantes.</p>
      <ul class="titles">
        <li><b>5×</b><span>Campeão Mundial IBJJF (2006–2009, 2017)</span></li>
        <li><b>4×</b><span>Campeão Mundial No-Gi IBJJF</span></li>
        <li><b>3×</b><span>Campeão Mundial ADCC (2013, 2015, 2017)</span></li>
        <li><b>HOF</b><span>Hall da Fama IBJJF e ADCC</span></li>
      </ul>
      <a class="btn ghost" href="/instructors/" style="margin-top:14px">Conheça os professores</a>
    </div>
  </div>
</section>

<section class="mat">
  <div class="wrap">
    <p class="eyebrow rv">Mais</p>
    <h2 class="display rv">Todo o resto, a um toque.</h2>
    <div class="explore rv">
      <a href="/start/"><b>Seu primeiro mês</b><span>Como são as primeiras quatro semanas, passo a passo.</span></a>
      <a href="/kids/"><b>Crianças</b><span>De 3 a 16 anos, por faixa etária, com os horários da aula experimental grátis.</span></a>
      <a href="/pricing/"><b>Mensalidade</b><span>8, 12 ou aulas ilimitadas por mês, e o plano família.</span></a>
      <a href="/visit/"><b>Visite-nos</b><span>4929 Wilshire: estacionamento, o que levar, o que acontece ao entrar.</span></a>
      <a href="/faq/"><b>Perguntas</b><span>Respostas diretas a tudo o que perguntam antes da primeira aula.</span></a>
    </div>
  </div>
</section>



<!-- /wp:html -->
