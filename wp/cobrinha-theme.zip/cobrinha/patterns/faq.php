<?php
/**
 * Title: Questions and answers
 * Slug: cobrinha/faq
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="phero">
  <div class="wrap">
    <p class="crumbs"><a href="/">Home</a> / Questions</p>
    <p class="eyebrow">Questions &amp; answers</p>
    <h1 class="display">Everything people ask us.</h1>
    <p class="lead">If your question isn't here, call <a class="link" href="tel:+13239319953">(323) 931-9953</a> or <a class="link" href="/contact/">send a message</a>. A person answers.</p>
  </div>
</section>

<section>
  <div class="wrap grid-2" style="align-items:start">
    <div class="rv l">
      <h2 class="display" id="beginners">Adult beginners</h2>
      <div class="faq">
        <details><summary>I've never done any martial art. Will I be lost?</summary><div class="ans">No. Beginners start in a four-week course built for people with zero experience, then move into Fundamentals with others at the same level. Nobody spars in their first class unless they ask to.</div></details>
        <details><summary>Am I too old or too out of shape?</summary><div class="ans">We have students who started at 50 and 60. Jiu-Jitsu is technique and leverage, not strength, and the pace of the beginners course is set by the room. Fitness comes from the training, not before it.</div></details>
        <details><summary>When is the free trial?</summary><div class="ans">Any Monday or Wednesday at 8:00 pm, or Thursday at 6:10 pm. Book ahead and sign the waiver online first (it creates your profile) so an instructor is ready for you. Gear rental is $20 and is refunded in full when you sign up.</div></details>
        <details><summary>What do I wear to the first class?</summary><div class="ans">Comfortable athletic clothes, and rent a gi at the desk. If you continue, you'll train in a blue or white Alliance or Cobrinha gi with a rash guard underneath; we keep everyone one team.</div></details>
        <details><summary>Is it safe? Will I get hurt?</summary><div class="ans">Jiu-Jitsu has no striking. Beginners drill techniques with a partner under a coach's eye, and every roll ends the moment someone taps. Injuries are far rarer than in most team sports.</div></details>
        <details><summary>How often should I come?</summary><div class="ans">Two or three times a week is the sweet spot for beginners. Once a week works; you'll just move a little slower.</div></details>
        <details><summary>How long until a blue belt?</summary><div class="ans">Typically one and a half to two years of consistent training. Stripes come along the way, roughly every few months, so you always know where you stand.</div></details>
        <details><summary>What if I have an old injury?</summary><div class="ans">Tell the coach before class. Almost everything can be adapted, and the beginners course avoids the positions that stress knees and shoulders until you're ready for them.</div></details>
      </div>

      <h2 class="display" id="cost" style="margin-top:56px">Cost &amp; membership</h2>
      <div class="faq">
        <details><summary>How much does it cost?</summary><div class="ans">Adults: Silver $257 a month for 8 classes, Gold $299 for 12, Platinum $327 unlimited. Kids and teens: $257 a month. Memberships renew monthly and need 30 days' notice to cancel; family discount: 10% off the second family member, 15% off the third, 20% off the fourth. <a class="link" href="/pricing/">Membership details</a>.</div></details>
        <details><summary>How much is the beginners course?</summary><div class="ans">$149 for the four-week course: Monday and Wednesday at 8:00 pm and Thursday at 6:10 pm, three classes a week. You can start any week, and your first class is free.</div></details>
        <details><summary>Is the trial really free?</summary><div class="ans">Yes. The only charge is gear rental, $20 for adults and $15 for kids, and it is refunded in full when you sign up.</div></details>
        <details><summary>Is there a contract?</summary><div class="ans">Memberships renew every month and can be cancelled with 30 days' notice. Ask the front desk for the current terms and the family options.</div></details>
        <details><summary>What do private lessons cost?</summary><div class="ans">Brown belt: $160 for one 60-minute lesson, $725 for five, $1,350 for ten. Black belt: $220, $955 and $1,800. A small group of four is $80 per person. Lessons with Cobrinha are by request. All privates are scheduled in advance with the instructor; no-shows use the lesson.</div></details>
        <details><summary>Can I pause my membership?</summary><div class="ans">Talk to the front desk; holds are handled case by case for travel, injury and school terms.</div></details>
      </div>

      <h2 class="display" id="visiting" style="margin-top:56px">Visiting &amp; parking</h2>
      <div class="faq">
        <details><summary>Where do I park?</summary><div class="ans">The building lot, with validation from the front desk: free before 8:30 am, after 6 pm and on weekends; $5 for two hours midday. Free street parking on Highland Ave.</div></details>
        <details><summary>Where exactly is the academy?</summary><div class="ans">4929 Wilshire Blvd, Suite 104, Los Angeles 90010, in the lobby of the office building on the corner of Wilshire and Highland in Hancock Park.</div></details>
        <details><summary>I already train elsewhere. Can I drop in?</summary><div class="ans">Yes. Drop-ins with experience are $60 a class, gi included, and the $60 is refunded if you sign up. Call or email ahead to reserve a spot and sign the waiver online. Everyone trains in a blue or white Alliance or Cobrinha gi. Cobrinha's advanced class is blue belt and up.</div></details>
        <details><summary>Is the academy open on Sundays?</summary><div class="ans">Sunday is a members-only open mat at 10 am, all levels. No classes; the front desk opens for members.</div></details>
        <details><summary>Are there showers?</summary><div class="ans">Yes, in both the men's and women's changing rooms.</div></details>
      </div>
    </div>

    <div class="rv r">
      <h2 class="display" id="kids">Kids &amp; teens</h2>
      <div class="faq">
        <details><summary>Can my child start at 3?</summary><div class="ans">Yes. Baby Eagles is for ages 3–4, Little Eagles 5–6, Eagle Warriors 7–12, Teens 13–16.</div></details>
        <details><summary>When is the kids' free trial?</summary><div class="ans">Ages 3–4: Tuesday or Thursday 3:30 pm (30 minutes). Ages 5–6: Monday or Wednesday 3:30 pm (30 minutes). Ages 7–12: any Monday to Thursday at 5:00 pm. Teens 13–16: Tuesday or Thursday 5:00 pm. Trials are one-on-one with an instructor, so please book ahead. Gear rental is $15, refunded in full when they sign up.</div></details>
        <details><summary>What does my child wear to the trial class?</summary><div class="ans">Comfortable clothes they can move in; rent a gi at the desk. Long hair tied back, no jewelry, nails trimmed.</div></details>
        <details><summary>Can I watch?</summary><div class="ans">Yes. The lounge looks onto the mat. For the youngest we ask parents to stay for the first few classes.</div></details>
        <details><summary>How much is the kids program?</summary><div class="ans">$257 a month, renewing monthly with 30 days' notice to cancel. Family discount: 10% off the second family member, 15% off the third, 20% off the fourth (applied to the members who join after the first).</div></details>
        <details><summary>My child is shy. Will they be pushed?</summary><div class="ans">They'll be invited, not pushed. Coaches partner shy kids with patient ones and let them join at their pace. Most are on the mat by the second class.</div></details>
        <details><summary>Does my child have to compete?</summary><div class="ans">No. Competition is optional. For the kids who ask, there is a competition team coached the way Cobrinha coached world champions.</div></details>
        <details><summary>How often should they come?</summary><div class="ans">Twice a week is ideal for the little ones; Warriors and Teens can train up to five days.</div></details>
      </div>

      <h2 class="display" id="womens" style="margin-top:56px">Women's program</h2>
      <div class="faq">
        <details><summary>Is the women's class really women only?</summary><div class="ans">Yes. It is taught by Ursula Valverde, a female black belt, and only women train in it. Tuesday 8 am and Saturday 11:15 am. Free trial: Wednesday 6:10 pm is the best slot; Tuesday or Thursday 6:10 pm also work.</div></details>
        <details><summary>Is there a women's beginner program?</summary><div class="ans">Yes. The next women's four-week beginner program starts Monday, October 5. If you'd rather not wait, start the beginners course now ($149 for your first month, three classes a week: Monday and Wednesday 8 pm, Thursday 6:10 pm) and add the women's class on Tuesday mornings and Saturdays.</div></details>
        <details><summary>Can women train in the regular classes too?</summary><div class="ans">Of course. Many do both. The women's class is an option, not a limit.</div></details>
      </div>

      <h2 class="display" id="programs" style="margin-top:56px">Programs</h2>
      <div class="faq">
        <details><summary>What's the difference between Gi and No-Gi?</summary><div class="ans">Gi is the traditional kimono, with grips on the collar and sleeves; No-Gi is a rash guard and shorts, faster and closer to wrestling. Both are taught here: No-Gi runs six times a week, Tuesday and Thursday at 12 pm, 6:10 pm and 7:20 pm. Beginners usually start in the gi.</div></details>
        <details><summary>What are the levels?</summary><div class="ans">Beginners course, then Fundamentals 1 (all levels), Fundamentals 2 (three stripes), Fundamentals 3 (four stripes), then Advanced (blue belt and up), which Cobrinha teaches.</div></details>
        <details><summary>Does Cobrinha teach?</summary><div class="ans">Yes. He teaches the advanced program every week and sets the curriculum for every level; every class is led by a black or brown belt he promoted or approved.</div></details>
        <details><summary>Do you offer online training?</summary><div class="ans">Yes, through <a class="link" href="https://www.cobrinhaonline.com/" target="_blank" rel="noopener">Cobrinha Online</a>, for training at home or while traveling.</div></details>
      </div>
    </div>
  </div>
</section>

<!-- /wp:html -->
