<?php
/**
 * Title: Instructors
 * Slug: cobrinha/instructors
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="phero">
  <div class="wrap">
    <p class="crumbs"><a href="/">Home</a> / Instructors</p>
    <p class="eyebrow">The team</p>
    <h1 class="display">Taught by champions.</h1>
    <p class="lead">Every class at the academy is led by a black or brown belt promoted or approved by Cobrinha. These are the people you'll train with.</p>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="people rv stagger">
      <article class="person">
        <div class="ph"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/cobrinha.webp" alt="Rubens Cobrinha Charles" loading="lazy"></div>
        <div class="pb">
          <h3>Rubens "Cobrinha" Charles</h3>
          <p class="role">Head coach · 4th-degree black belt</p>
          <p>Five-time IBJJF World Champion, four-time No-Gi World Champion, three-time ADCC Champion, and the only black belt ever to complete the Super Grand Slam. IBJJF and ADCC Hall of Fame. Teaches the advanced program and sets the curriculum for every level. <a class="link" href="https://www.instagram.com/cobrinhacharles/" target="_blank" rel="noopener">@cobrinhacharles</a> · <a class="link" href="https://www.cobrinhaonline.com/" target="_blank" rel="noopener">Cobrinha Online</a></p>
        </div>
      </article>
      <article class="person">
        <div class="ph"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/kennedy.webp" alt="Kennedy Maciel" loading="lazy"></div>
        <div class="pb">
          <h3>Kennedy Maciel</h3>
          <p class="role">Black belt · adult program</p>
          <p>Black belt under Cobrinha. Started training in 2012 after moving to Los Angeles from São Carlos, Brazil. World Champion at every colored belt from white to brown, 2016 European Champion, 2017 Pan and Abu Dhabi World Pro Champion, 2019 ADCC silver medalist. Teaches the adult classes.</p>
        </div>
      </article>
      <article class="person">
        <div class="ph ph-init">U</div>
        <div class="pb">
          <h3>Ursula Valverde</h3>
          <p class="role">Black belt · women's program &amp; privates</p>
          <p>Female black belt who leads the women's classes and free trial, and teaches private lessons through the week. She and Paulo, her husband, teach as a team. Focused on self-defense, technique and building confidence in women who are new to the mat. <a class="link" href="https://www.instagram.com/uchavalverde/" target="_blank" rel="noopener">@uchavalverde</a></p>
        </div>
      </article>
      <article class="person">
        <div class="ph ph-init">M</div>
        <div class="pb">
          <h3>Makoto</h3>
          <p class="role">Black belt · instructor</p>
          <p>Black belt, active competitor and instructor on the academy team; most recently won a professional super-fight by submission in 20 seconds. <a class="link" href="https://www.instagram.com/makoto_bjj/" target="_blank" rel="noopener">@makoto_bjj</a></p>
        </div>
      </article>
      <article class="person">
        <div class="ph ph-init">E</div>
        <div class="pb">
          <h3>Eduardo</h3>
          <p class="role">Brown belt · morning program</p>
          <p>Brown belt on the academy team. Runs the early-morning Fundamentals classes for people who train before work.</p>
        </div>
      </article>
      <article class="person">
        <div class="ph ph-init">C</div>
        <div class="pb">
          <h3>Cleber Sousa</h3>
          <p class="role">Black belt · instructor &amp; competitor</p>
          <p>Black belt on the academy team and an active competitor, with a recent first-place finish in the black belt featherweight division. Full bio to come.</p>
        </div>
      </article>
      <article class="person">
        <div class="ph ph-init">P</div>
        <div class="pb">
          <h3>Paulo</h3>
          <p class="role">Black belt · instructor</p>
          <p>Black belt on the academy team and Ursula's husband; students on Yelp single him out for going above and beyond for beginners. Belt, bio and photo to come from the academy.</p>
        </div>
      </article>
    </div>
    <p class="small muted rv" style="margin-top:22px">Instructor bios and photos are being updated. If you teach at the academy and your details are missing or wrong, tell the front desk.</p>
  </div>
</section>

<!-- /wp:html -->
