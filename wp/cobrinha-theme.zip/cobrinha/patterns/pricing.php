<?php
/**
 * Title: Membership
 * Slug: cobrinha/pricing
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="phero">
  <div class="wrap">
    <p class="crumbs"><a href="/">Home</a> / Membership</p>
    <p class="eyebrow">Membership</p>
    <h1 class="display">Membership.</h1>
    <p class="lead">Try a class free first. Then pick the plan that matches how often you'll actually train, from eight classes a month to unlimited. Memberships renew monthly and can be cancelled with 30 days' notice. The whole academy, every instructor and every program is included, and the desk goes through the plans with you after your first class.</p>
    <div class="hero-actions" style="margin-top:22px"><a class="btn red big" href="/free-class/">Book a free class</a></div>
  </div>
</section>

<section class="dark">
  <div class="wrap">
    <div class="plans rv up">
      <div class="plan" style="--i:0"><p class="plan-name">Silver</p><p class="plan-count">8<span>classes a month</span></p><p class="plan-per">Twice a week, any program</p></div>
      <div class="plan hot" style="--i:1"><p class="plan-name">Gold</p><p class="plan-count">12<span>classes a month</span></p><p class="plan-per">Three times a week</p></div>
      <div class="plan" style="--i:2"><p class="plan-name">Platinum</p><p class="plan-count">Unlimited<span>classes</span></p><p class="plan-per">Every day, gi and no-gi</p></div>
      <div class="plan" style="--i:3"><p class="plan-name">Kids &amp; teens</p><p class="plan-count">3–16<span>years old</span></p><p class="plan-per">Their age group · family discount</p></div>
    </div>
    <p class="small rv" style="margin-top:22px;color:var(--tx-lm)">Memberships renew monthly; cancellation needs 30 days' notice. Family discount for the second family member onward. <a class="link" href="/programs/#private">Private lessons</a> are arranged separately with the instructor. New to Jiu-Jitsu? Start with the <a class="link" href="/start/">four-week Beginners course</a>, Monday and Wednesday 8 pm and Thursday 6:10 pm, any week.</p>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="sec-head rv">
      <p class="eyebrow">What every membership includes</p>
      <h2 class="display">One price, the whole academy.</h2>
    </div>
    <div class="grid-4 rv stagger">
      <div class="step" style="--i:0"><h3>World-champion curriculum</h3><p>Every level follows the curriculum Cobrinha built and teaches, from the beginners course to the advanced room.</p></div>
      <div class="step" style="--i:1"><h3>Six days a week</h3><p>Morning, lunchtime and evening classes Monday to Friday, plus Saturday. Fundamentals, Advanced, No-Gi and Women's all have their own slots.</p></div>
      <div class="step" style="--i:2"><h3>Gi and No-Gi</h3><p>Both programs are included. Train in the kimono, train without it, or do both.</p></div>
      <div class="step" style="--i:3"><h3>Belts and stripes</h3><p>Promotions are earned on the mat and tracked, so you always know where you stand and what's next.</p></div>
      <div class="step" style="--i:4"><h3>Changing rooms and showers</h3><p>Men's and women's changing rooms with showers, and a lounge for family and visitors.</p></div>
      <div class="step" style="--i:5"><h3>Parking with validation</h3><p>Free before 8:30 am, after 6 pm and on weekends; $5 for two hours midday.</p></div>
      <div class="step" style="--i:6"><h3>Competition team</h3><p>Optional for adults and kids who want to test themselves, coached inside the advanced program.</p></div>
      <div class="step" style="--i:7"><h3>A room that knows your name</h3><p>Hundreds of students, one head coach, sixteen years on the same corner of Wilshire.</p></div>
    </div>
  </div>
</section>

<section class="mat">
  <div class="wrap">
    <div class="sec-head rv"><p class="eyebrow">Before you decide</p><h2 class="display">The free class comes first.</h2><p class="lead">Nobody is asked to choose a plan before they've trained. Adults: any Monday or Wednesday at 8 pm, or Thursday at 6:10 pm. Kids: their age group's trial slot. Gear rental is $20 for adults and $15 for kids, refunded in full when you sign up.</p></div>
    <div class="rv" style="display:flex;gap:12px;flex-wrap:wrap"><a class="btn red big" href="/free-class/">Book a free class</a><a class="btn line big" href="/faq/#cost">Membership questions</a></div>
  </div>
</section>

<!-- /wp:html -->
