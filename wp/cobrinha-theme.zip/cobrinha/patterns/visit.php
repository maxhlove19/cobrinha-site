<?php
/**
 * Title: Visiting, parking and what to expect
 * Slug: cobrinha/visit
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="phero">
  <div class="wrap">
    <p class="crumbs"><a href="/">Home</a> / Visiting &amp; parking</p>
    <p class="eyebrow">Visitor information</p>
    <h1 class="display">Before you come in.</h1>
    <p class="lead">Where to park, what to wear, and how the mat works. Visiting grapplers: call or email ahead so we can reserve your spot in class.</p>
  </div>
</section>

<section>
  <div class="wrap grid-2">
    <div class="rv">
      <p class="eyebrow">Parking</p>
      <h2 class="display">The building lot, with validation.</h2>
      <p class="lead">The academy is in the lobby of the office building on the corner of Wilshire and Highland. Get your ticket validated at the front desk.</p>
      <div class="strip" style="grid-template-columns:1fr">
        <div class="srow"><b>Before 8:30 am</b><span>Free with validation</span></div>
        <div class="srow"><b>8:30 am – 6:00 pm</b><span>$5 for two hours with validation</span></div>
        <div class="srow"><b>After 6:00 pm</b><span>Free with validation</span></div>
        <div class="srow"><b>Weekends</b><span>Free with validation</span></div>
        <div class="srow"><b>Highland Ave</b><span>Free street parking</span></div>
      </div>
      <p class="small muted">The parking system changed recently; here is a <a class="link" href="https://youtu.be/nevrzp8Dufo" target="_blank" rel="noopener">two-minute video</a> on how it works.</p>
    </div>
    <div class="rv">
      <p class="eyebrow">Uniform</p>
      <h2 class="display">What to wear.</h2>
      <ul class="checks">
        <li><b>First class:</b> athletic clothes; rent a gi at the desk ($20 adults, $15 kids, refunded when you sign up).</li>
        <li><b>Gi classes:</b> a blue or white Alliance or Cobrinha gi with a rash guard underneath. No T-shirts, no other colors or teams' patches: we keep everyone one team.</li>
        <li><b>No-Gi classes:</b> academy ranked rash guard with no other affiliation patches, black shorts with black tights underneath. Same for men and women.</li>
        <li>Don't wear the same gi for two classes in a row. Changing rooms and showers are available.</li>
      </ul>
      <p class="eyebrow" style="margin-top:28px">Drop-ins</p>
      <p>Visiting students with experience are welcome. A drop-in class is <b>$60, gi included</b>, and the $60 is refunded if you sign up with us. Call <a class="link" href="tel:+13239319953">(323) 931-9953</a> or email <a class="link" href="mailto:info@cobrinhabjj.com">info@cobrinhabjj.com</a> ahead of time to reserve a spot, and <a class="link" href="https://cobrinha-jiu-jitsu-academy.gymdesk.com/signup" target="_blank" rel="noopener">sign the waiver online</a> before you arrive.</p>
    </div>
  </div>
</section>

<section class="mat">
  <div class="wrap">
    <div class="sec-head rv"><p class="eyebrow">Mat etiquette</p><h2 class="display">How the room works.</h2><p class="lead">These are the habits that keep a room of two hundred people safe and friendly. New students pick them up in a week.</p></div>
    <div class="grid-2 rv">
      <ul class="checks">
        <li>Bow when you step on and off the mat. Shake hands with your teammates when you arrive.</li>
        <li>Introduce yourself to visitors and newcomers. Treat them the way you wanted to be treated on your first day.</li>
        <li>Full gi and a properly tied belt before you step on. Gi tops and rash guards stay on in the mat and lobby areas.</li>
        <li>Shoes off before the mat, shoes on the moment you leave it, even for the bathroom.</li>
        <li>Fingernails and toenails short. No jewelry.</li>
        <li>No food, gum or phones on the mat. No photos or video during class.</li>
      </ul>
      <ul class="checks">
        <li>Be on time. If you're late, wait at the edge of the mat until the instructor waves you in.</li>
        <li>Ask the instructor before leaving the mat.</li>
        <li>Quiet while the instructor is talking; respectful language always, especially around the kids.</li>
        <li>Shake or touch hands before and after every roll, and thank your partner.</li>
        <li>Use only as much force as the technique needs. Nobody gets hurt on purpose here.</li>
        <li>When you're given a drill, keep drilling until you're told otherwise. Then have fun.</li>
      </ul>
    </div>
  </div>
</section>

<!-- /wp:html -->
