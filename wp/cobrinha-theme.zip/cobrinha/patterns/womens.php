<?php
/**
 * Title: Women's Brazilian Jiu-Jitsu in Los Angeles
 * Slug: cobrinha/womens
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="phero img">
  <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-womens-2.webp" alt="" aria-hidden="true">
  <div class="wrap">
    <p class="crumbs"><a href="/">Home</a> / <a href="/programs/">Programs</a> / Women's</p>
    <p class="eyebrow">Women only · black belt coach</p>
    <h1 class="display">Stronger. Safer.<br>On your terms.</h1>
    <p class="lead">A class created for women to get stronger, learn real self-defense and build confidence with people who understand what that takes. No experience needed. All levels train together.</p>
    <div class="hero-actions" style="margin-top:22px"><a class="btn red big" href="free-class.html?program=womens">Book the women's free trial</a><a class="btn ghost big" href="#times">Class times</a></div>
  </div>
</section>

<section>
  <div class="wrap split">
    <div class="rv l">
      <p class="eyebrow">Your coach</p>
      <h2 class="display">Ursula Valverde, black belt.</h2>
      <p class="lead">Ursula has taught for more than twenty years and leads every women's class here. Her classes start from what actually happens, a grab, a shove, being pinned, and build the technique that gets you out and away, then the sport on top of it.</p>
      <ul class="checks">
        <li>Women-only room, women's changing room and showers</li>
        <li>Self-defense first: wrist grabs, hair grabs, being pinned, getting up and getting away</li>
        <li>All levels together; beginners partner with patient training partners</li>
        <li>Train the women's class only, or add it to the full schedule. Many do both.</li>
      </ul>
      <a class="btn line" href="/instructors/">Meet the instructors</a>
    </div>
    <div class="media tall rv r"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-womens-1.webp" alt="Women's class at the academy: a coach guiding a student through a pin escape" loading="lazy"></div>
  </div>
</section>

<section class="mat" id="times">
  <div class="wrap grid-2">
    <div class="rv">
      <p class="eyebrow">Class times</p>
      <h2 class="display">Three slots a week, one free.</h2>
      <p class="lead">The next women's four-week beginner program starts Monday, October 5. Want to start sooner? Join the beginners course now: $149 for your first month, three classes a week (Monday and Wednesday 8 pm, Thursday 6:10 pm), and add the women's class on Tuesday mornings and Saturdays. The free trial is on Wednesday at 6:10 pm; Tuesday or Thursday at 6:10 pm also work. Gear rental is $20, refunded in full when you sign up.</p>
    </div>
    <div class="strip rv" style="grid-template-columns:1fr">
      <div class="srow"><b>Tuesday · Women's class</b><span>8:00 – 9:00 am</span></div>
      <div class="srow"><b>Saturday · Women's class</b><span>11:15 am – 12:15 pm</span></div>
      <div class="srow"><b>Wednesday · Free trial (best slot)</b><span>6:10 – 7:10 pm</span></div>
      <div class="srow"><b>Tuesday or Thursday · Free trial</b><span>6:10 – 7:10 pm</span></div>
      <div class="srow"><b>Monday, October 5 · Women's four-week beginner program</b><span>Starts · book ahead</span></div>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="sec-head rv"><p class="eyebrow">Why women train here</p><h2 class="display">What you get.</h2></div>
    <div class="grid-3 rv stagger">
      <div class="step"><h3>Real self-defense</h3><p>Technique built so a smaller person controls a bigger one. You learn to stay calm, get up and get away, and you practice it until it is automatic.</p></div>
      <div class="step"><h3>Strength and endurance</h3><p>An hour on the mat is strength, cardio and mobility at once, with people cheering you on. Fitness comes from the training, not before it.</p></div>
      <div class="step"><h3>A room that has your back</h3><p>Women who started where you are, a coach who remembers your name, and a wider academy with a 16-year record of looking after beginners.</p></div>
    </div>
  </div>
</section>

<section class="mat">
  <div class="wrap">
    <div class="sec-head rv"><p class="eyebrow">Questions</p><h2 class="display">Before your first class.</h2></div>
    <div class="faq rv">
      <details><summary>Is it really women only?</summary><div class="ans">Yes. Only women train in the women's class, and it is taught by a female black belt. The wider academy classes are mixed and open to you as well.</div></details>
      <details><summary>What do I wear?</summary><div class="ans">Comfortable athletic clothes, hair tied back, no jewelry. Rent a gi at the desk for the trial. If you join, you'll train in a blue or white Alliance or Cobrinha gi with a rash guard underneath.</div></details>
      <details><summary>I've never done anything like this. Will I be paired with someone experienced?</summary><div class="ans">Yes, with someone patient. Nobody spars in their first class unless they ask to.</div></details>
      <details><summary>How much is it?</summary><div class="ans">The same memberships as the rest of the academy: from $257 a month for 8 classes to $327 unlimited. <a class="link" href="/pricing/">Membership details</a>.</div></details>
    </div>
  </div>
</section>

<!-- /wp:html -->
