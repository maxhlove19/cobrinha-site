<?php
/**
 * Title: Alliance Jiu Jitsu Los Angeles by Cobrinha
 * Slug: cobrinha/front-page
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<header class="hero">
  <img class="hero-img" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/hero-mat.webp" alt="Cobrinha seated at the front of a full mat of students at the Los Angeles academy" fetchpriority="high" width="1800" height="1013">
  <div class="hero-in">
    <div class="hero-copy">
    <p class="eyebrow light">Brazilian Jiu-Jitsu · Wilshire &amp; Highland, Los Angeles</p>
    <div class="next" id="nextClass"><span class="dot"></span><span>Loading today's classes…</span></div>
    <h1 class="display">Train with a legend.<br><span class="thin">Start as a beginner.</span></h1>
    <p class="hero-badge">The only Super Grand Slam champion in history</p>
    <p class="lead">Led by Rubens "Cobrinha" Charles, five-time World Champion. <span data-years>16</span> years on Wilshire. Start with the four-week Beginners course.</p>
    <div class="hero-actions">
      <a class="btn red big" href="/start/">Start training</a>
      <a class="btn ghost big" href="/schedule/">See the schedule</a>
    </div>
    <div class="chips">
      <span class="chip"><b data-years>16</b> years on Wilshire</span>
      <span class="chip"><b><span class="star">★</span> 4.9</b> on Google</span>
      <span class="chip"><b>5×</b> World Champion head coach</span>
      <span class="chip"><b>Only</b> Super Grand Slam champion in history</span>
    </div>
    </div>
  </div>
</header>

<section class="dark proof">
  <div class="wrap proof-in">
    <div class="stat"><b><span data-count="16" data-years>0</span></b><span>Years on Wilshire</span></div>
    <div class="stat"><b><span data-count="5">0</span><i>×</i></b><span>IBJJF World Champion</span></div>
    <div class="stat"><b><span data-count="3">0</span><i>×</i></b><span>ADCC Champion</span></div>
    <div class="stat"><b><span data-count="4.9">0</span></b><span>Google rating, 200 reviews</span></div>
    <div class="stat"><b>Only<i> one </i>ever</b><span>Super Grand Slam champion</span></div>
  </div>
</section>

<div class="ticker" aria-hidden="true"><div class="ticker-in"><span><b data-years style="font-weight:inherit">16</b> years on Wilshire</span><span>5× World Champion</span><span>3× ADCC Champion</span><span>Only Super Grand Slam champion ever</span><span>4.9★ on Google</span><span>Free kids' trial class</span><span>Kids from age 3</span><span>Women's program</span><span>Six No-Gi classes a week</span><span><b data-years style="font-weight:inherit">16</b> years on Wilshire</span><span>5× World Champion</span><span>3× ADCC Champion</span><span>Only Super Grand Slam champion ever</span><span>4.9★ on Google</span><span>Free kids' trial class</span><span>Kids from age 3</span><span>Women's program</span><span>Six No-Gi classes a week</span></div></div>


<section>
  <div class="wrap">
    <div class="finder rv" id="finder">
      <div>
        <p class="eyebrow light">Thirty seconds</p>
        <h3>Which class is right for you?</h3>
        <div class="fq" style="margin-top:18px">
          <p>Who is it for?</p>
          <div class="opts"><button class="opt" data-g="who" data-v="me" aria-pressed="true">Me</button><button class="opt" data-g="who" data-v="kid" aria-pressed="false">My child</button><button class="opt" data-g="who" data-v="woman" aria-pressed="false">Me · women-only class</button></div>
          <p>Experience</p>
          <div class="opts"><button class="opt" data-g="exp" data-v="none" aria-pressed="true">None</button><button class="opt" data-g="exp" data-v="some" aria-pressed="false">White belt · some</button><button class="opt" data-g="exp" data-v="blue" aria-pressed="false">Blue belt and up</button></div>
          <p>What you want</p>
          <div class="opts"><button class="opt" data-g="goal" data-v="fit" aria-pressed="true">Fitness &amp; self-defense</button><button class="opt" data-g="goal" data-v="comp" aria-pressed="false">Compete</button><button class="opt" data-g="goal" data-v="nogi" aria-pressed="false">No-Gi</button></div>
        </div>
      </div>
      <div class="fres" id="fres" aria-live="polite"></div>
    </div>
  </div>
</section>






<section>
  <div class="wrap split">
    <div class="rv">
      <p class="eyebrow">Schedule</p>
      <h2 class="display" id="todayName">Today</h2>
      <p class="lead">Classes six days a week, 6:30 am to 9 pm, plus a members-only All Levels class on Sunday morning. New students sign up ahead so an instructor is ready for you. Beginners, Fundamentals, Advanced, No-Gi, Women's and Kids each have their own slots, so you're always training with your level.</p>
      <a class="btn line" href="/schedule/">Full weekly schedule</a>
    </div>
    <div class="dark rv" style="padding:26px;border-radius:4px">
      <div class="today" id="today"></div>
    </div>
  </div>
</section>






<section class="mat">
  <div class="wrap">
    <p class="eyebrow rv">Go deeper</p>
    <h2 class="display rv">Everything else, one tap away.</h2>
    <div class="explore rv">
      <a href="/start/"><b>Your first month</b><span>What the first four weeks look like, step by step.</span></a>
<a href="/programs/"><b>Programs</b><span>Beginners, Fundamentals, Advanced, No-Gi, Women's, Private — every adult class.</span></a>
<a href="/academy/"><b>Cobrinha & the academy</b><span>The head coach, the team, the room, 4929 Wilshire since 2010.</span></a>
<a href="/accomplishments/"><b>Competition record</b><span>Every title, year by year, checked against the federations.</span></a>
<a href="/reviews/"><b>What students say</b><span>Real Google and Yelp reviews from members, parents and visitors.</span></a>
<a href="/instructors/"><b>Instructors</b><span>Who teaches what.</span></a>
      <a href="/kids/"><b>Kids</b><span>Ages 3 to 16, by age group, with the free trial times.</span></a>
      <a href="/pricing/"><b>Membership</b><span>8, 12 or unlimited classes a month, and the family plan.</span></a>
      <a href="/visit/"><b>Visit us</b><span>4929 Wilshire: parking, what to bring, what happens when you walk in.</span></a>
      <a href="/faq/"><b>Questions</b><span>Straight answers to everything people ask before their first class.</span></a>
    </div>
  </div>
</section>


<script>
window.SCHEDULE=[
{d:"Sun",t:"10:00 am",c:"All Levels · members only"},
{d:"Mon",t:"6:30 am",c:"All Levels · 3 stripes+"},{d:"Mon",t:"12:00 pm",c:"Advanced BJJ · blue belt+"},{d:"Mon",t:"4:10 pm",c:"Little Eagles"},{d:"Mon",t:"5:00 pm",c:"Eagle Warriors"},{d:"Mon",t:"6:10 pm",c:"Fundamentals 2 · 3 stripes+"},{d:"Mon",t:"6:10 pm",c:"Women's class"},{d:"Mon",t:"7:20 pm",c:"Advanced · blue belt+"},{d:"Mon",t:"8:00 pm",c:"Fundamentals 1 · all levels"},
{d:"Tue",t:"6:30 am",c:"Fundamentals 1 · all levels"},{d:"Tue",t:"8:00 am",c:"Women's class"},{d:"Tue",t:"12:00 pm",c:"No-Gi Advanced · blue belt+"},{d:"Tue",t:"4:10 pm",c:"Baby Eagles"},{d:"Tue",t:"5:00 pm",c:"Eagle Warriors"},{d:"Tue",t:"5:00 pm",c:"Eagle Teens"},{d:"Tue",t:"6:10 pm",c:"Fundamentals 1"},{d:"Tue",t:"6:10 pm",c:"No-Gi Fundamentals"},{d:"Tue",t:"7:20 pm",c:"No-Gi · 3 stripes+"},
{d:"Wed",t:"6:30 am",c:"All Levels · 3 stripes+"},{d:"Wed",t:"12:00 pm",c:"Advanced BJJ · blue belt+"},{d:"Wed",t:"4:10 pm",c:"Little Eagles"},{d:"Wed",t:"5:00 pm",c:"Eagle Warriors"},{d:"Wed",t:"6:10 pm",c:"Fundamentals 2 · 3 stripes+"},{d:"Wed",t:"6:10 pm",c:"Women's class"},{d:"Wed",t:"7:20 pm",c:"Advanced · blue belt+"},{d:"Wed",t:"8:00 pm",c:"Fundamentals 1 · all levels"},
{d:"Thu",t:"6:30 am",c:"Fundamentals 1 · all levels"},{d:"Thu",t:"12:00 pm",c:"No-Gi Advanced · blue belt+"},{d:"Thu",t:"4:10 pm",c:"Baby Eagles"},{d:"Thu",t:"5:00 pm",c:"Eagle Warriors"},{d:"Thu",t:"5:00 pm",c:"Eagle Teens"},{d:"Thu",t:"6:10 pm",c:"Fundamentals 1"},{d:"Thu",t:"6:10 pm",c:"No-Gi Fundamentals"},{d:"Thu",t:"7:20 pm",c:"No-Gi · 3 stripes+"},
{d:"Fri",t:"6:30 am",c:"All Levels · 3 stripes+"},{d:"Fri",t:"12:00 pm",c:"Advanced BJJ · blue belt+"},{d:"Fri",t:"4:10 pm",c:"Little Eagles"},{d:"Fri",t:"5:00 pm",c:"Eagle Warriors No-Gi · all levels"},{d:"Fri",t:"6:20 pm",c:"Fundamentals 2 · 4 stripes+"},
{d:"Sat",t:"9:00 am",c:"Eagle Warriors · all levels"},{d:"Sat",t:"10:00 am",c:"Capofit workout"},{d:"Sat",t:"11:15 am",c:"Fundamentals 3 · 4 stripes+"},{d:"Sat",t:"11:15 am",c:"Women's class"}
];
</script>

<!-- /wp:html -->
