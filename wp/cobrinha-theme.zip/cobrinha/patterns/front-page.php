<?php
/**
 * Title: Alliance Jiu Jitsu Los Angeles by Cobrinha
 * Slug: cobrinha/front-page
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<header class="hero">
  <img class="hero-img" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/hero-mat.webp" alt="Cobrinha seated at the front of a full mat of students at the Los Angeles academy" fetchpriority="high" width="1800" height="1013">
  <div class="hero-in">
    <div class="hero-copy">
    <p class="eyebrow light">Brazilian Jiu-Jitsu · Wilshire &amp; Highland, Los Angeles</p>
    <div class="next" id="nextClass"><span class="dot"></span><span>Loading today's classes…</span></div>
    <h1 class="display">Train with a legend.<br><span class="thin">Start as a beginner.</span></h1>
    <p class="hero-badge">The only Super Grand Slam champion in history</p>
    <p class="lead">Led by Rubens "Cobrinha" Charles, five-time World Champion. <span data-years>16</span> years on Wilshire. Start with the four-week Beginners course.</p>
    <div class="hero-actions">
      <a class="btn red big" href="/start/">Start training</a>
      <a class="btn ghost big" href="/schedule/">See the schedule</a>
    </div>
    <div class="chips">
      <span class="chip"><b data-years>16</b> years on Wilshire</span>
      <span class="chip"><b><span class="star">★</span> 4.9</b> on Google</span>
      <span class="chip"><b>5×</b> World Champion head coach</span>
      <span class="chip"><b>Only</b> Super Grand Slam champion in history</span>
    </div>
    </div>
  </div>
</header>

<section class="dark proof">
  <div class="wrap proof-in">
    <div class="stat"><b><span data-count="16" data-years>0</span></b><span>Years on Wilshire</span></div>
    <div class="stat"><b><span data-count="5">0</span><i>×</i></b><span>IBJJF World Champion</span></div>
    <div class="stat"><b><span data-count="3">0</span><i>×</i></b><span>ADCC Champion</span></div>
    <div class="stat"><b><span data-count="4.9">0</span></b><span>Google rating, 200 reviews</span></div>
    <div class="stat"><b>Only<i> one </i>ever</b><span>Super Grand Slam champion</span></div>
  </div>
</section>

<div class="ticker" aria-hidden="true"><div class="ticker-in"><span><b data-years style="font-weight:inherit">16</b> years on Wilshire</span><span>5× World Champion</span><span>3× ADCC Champion</span><span>Only Super Grand Slam champion ever</span><span>4.9★ on Google</span><span>Free kids' trial class</span><span>Kids from age 3</span><span>Women's program</span><span>Six No-Gi classes a week</span><span><b data-years style="font-weight:inherit">16</b> years on Wilshire</span><span>5× World Champion</span><span>3× ADCC Champion</span><span>Only Super Grand Slam champion ever</span><span>4.9★ on Google</span><span>Free kids' trial class</span><span>Kids from age 3</span><span>Women's program</span><span>Six No-Gi classes a week</span></div></div>


<section>
  <div class="wrap">
    <div class="finder rv" id="finder">
      <div>
        <p class="eyebrow light">Thirty seconds</p>
        <h3>Which class is right for you?</h3>
        <div class="fq" style="margin-top:18px">
          <p>Who is it for?</p>
          <div class="opts"><button class="opt" data-g="who" data-v="me" aria-pressed="true">Me</button><button class="opt" data-g="who" data-v="kid" aria-pressed="false">My child</button><button class="opt" data-g="who" data-v="woman" aria-pressed="false">Me · women-only class</button></div>
          <p>Experience</p>
          <div class="opts"><button class="opt" data-g="exp" data-v="none" aria-pressed="true">None</button><button class="opt" data-g="exp" data-v="some" aria-pressed="false">White belt · some</button><button class="opt" data-g="exp" data-v="blue" aria-pressed="false">Blue belt and up</button></div>
          <p>What you want</p>
          <div class="opts"><button class="opt" data-g="goal" data-v="fit" aria-pressed="true">Fitness &amp; self-defense</button><button class="opt" data-g="goal" data-v="comp" aria-pressed="false">Compete</button><button class="opt" data-g="goal" data-v="nogi" aria-pressed="false">No-Gi</button></div>
        </div>
      </div>
      <div class="fres" id="fres" aria-live="polite"></div>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="sec-head rv">
      <p class="eyebrow">Programs</p>
      <h2 class="display">A class for where you are.</h2>
    </div>
    <div class="prog rv stagger">
      <a class="pcard" href="/start/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/beginners.webp" alt="" loading="lazy" width="846" height="564"><div class="pin"><small>Adults · no experience</small><b>Beginners</b><span>Four-week course · start any week</span></div></a>
      <a class="pcard" href="/programs/#fundamentals"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-fundamentals.webp" alt="" loading="lazy" width="720" height="1280"><div class="pin"><small>Adults · white to blue</small><b>Fundamentals</b><span>Levels 1, 2 and 3 by stripe</span></div></a>
      <a class="pcard" href="/programs/#advanced"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-nogi-win.webp" alt="" loading="lazy" width="901" height="1496"><div class="pin"><small>Adults · blue belt and up</small><b>Advanced &amp; Competition</b><span>Cobrinha's room</span></div></a>
      <a class="pcard" href="/programs/#nogi"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-nogi-1.webp" alt="" loading="lazy" width="899" height="992"><div class="pin"><small>Adults · all levels</small><b>No-Gi</b><span>Six classes a week, Tuesday and Thursday</span></div></a>
      <a class="pcard" href="/womens/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-womens-1.webp" alt="" loading="lazy" width="640" height="665"><div class="pin"><small>Women only · black belt coach</small><b>Women's</b><span>Mon &amp; Wed 6:10 pm · Tue 8 am · Sat 11:15 am</span></div></a>
      <a class="pcard" href="/kids/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/kids-run.webp" alt="" loading="lazy" width="1800" height="1200"><div class="pin"><small>Ages 3–12</small><b>Kids · Eagles</b><span>Baby, Little and Warrior Eagles</span></div></a>
      <a class="pcard" href="/kids/#teens"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-kids-coach.webp" alt="" loading="lazy" width="640" height="1136"><div class="pin"><small>Ages 13–16</small><b>Teens</b><span>Tue &amp; Thu 5 pm</span></div></a>
      <a class="pcard" href="/programs/#private"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/cobrinha.webp" alt="" loading="lazy" width="500" height="749"><div class="pin"><small>One on one</small><b>Private lessons</b><span>Black and brown belt instructors</span></div></a>
    </div>
  </div>
</section>


<section class="dark" id="cobrinha">
  <div class="wrap split rev">
    <div class="media tall rv r"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/cobrinha.webp" alt="Rubens Cobrinha Charles in his Alliance gi, arms crossed, smiling" loading="lazy" width="500" height="749"></div>
    <div class="rv">
      <p class="eyebrow light">Head coach</p>
      <h2 class="display">Rubens "Cobrinha" Charles</h2>
      <p class="lead">The only black belt in history to win ADCC, the Worlds, the Pans, the Europeans and the Brazilian Nationals in a single year. He teaches on this mat every week, and he teaches beginners.</p>
      <div class="tl" id="tl" aria-label="Career timeline, tap a year">
        <button class="tli" data-d="Black belt from Fernando Tereré. Won the CBJJO World Championship the same year, then Pro Jiu-Jitsu X in Japan."><b>2005</b><span>Black belt</span></button>
        <button class="tli" data-d="First IBJJF World title at black belt, every opponent finished by submission. Titles followed in 2007, 2008 and 2009."><b>2006</b><span>World Champion</span></button>
        <button class="tli" data-d="IBJJF No-Gi World Champion in 2007 and 2008, again in 2011 and 2012."><b>2007</b><span>No-Gi Worlds</span></button>
        <button class="tli" data-d="Fourth straight IBJJF World title. Pan Champion 2007, 2008 and 2009."><b>2009</b><span>4th Worlds</span></button>
        <button class="tli" data-d="Opened Cobrinha Brazilian Jiu-Jitsu on Wilshire Boulevard, Los Angeles. Same corner ever since."><b>2010</b><span>Wilshire opens</span></button>
        <button class="tli" data-d="First ADCC World Championship gold, beating Rafael Mendes in the final. Won again in 2015 and 2017."><b>2013</b><span>ADCC gold</span></button>
        <button class="tli" data-d="The Super Grand Slam: Europeans, Pans, Brazilian Nationals, Worlds and ADCC in a single year. The only black belt in history to do it."><b>2017</b><span>Super Grand Slam</span></button>
        <button class="tli" data-d="IBJJF Hall of Fame and ADCC Hall of Fame. Voted Best Guard of the Decade by fellow world champions."><b>HOF</b><span>Hall of Fame</span></button>
      </div>
      <p class="tld" id="tld" aria-live="polite"></p>
      <p class="quote">"We don't just build competitors. We build champions for life."</p>
      <p class="muted">Cobrinha, to the kids' competition team</p>
      <a class="btn ghost" href="/instructors/" style="margin-top:14px">Meet all the instructors</a>
    </div>
  </div>
</section>

<section>
  <div class="wrap split">
    <div class="rv">
      <p class="eyebrow">Schedule</p>
      <h2 class="display" id="todayName">Today</h2>
      <p class="lead">Classes six days a week, 6:30 am to 9 pm, plus a members-only All Levels class on Sunday morning. New students sign up ahead so an instructor is ready for you. Beginners, Fundamentals, Advanced, No-Gi, Women's and Kids each have their own slots, so you're always training with your level.</p>
      <a class="btn line" href="/schedule/">Full weekly schedule</a>
    </div>
    <div class="dark rv" style="padding:26px;border-radius:4px">
      <div class="today" id="today"></div>
    </div>
  </div>
</section>




<section>
  <div class="wrap">
    <div class="sec-head rv">
      <p class="eyebrow">What students say</p>
      <h2 class="display">Rated 4.9 on Google.</h2>
    </div>
    <div class="rating rv">
      <b>4.9</b>
      <div><div class="stars" aria-label="4.9 out of 5 stars">★★★★★</div><div class="src">From 200 Google reviews · 4.7 on Yelp (120 reviews)</div></div>
      <a class="btn line" href="https://search.google.com/local/reviews?placeid=ChIJ9a1UHee4woARhGUPe_kWVfw" target="_blank" rel="noopener">Read the reviews</a>
    </div>
    <div class="grid-4 rv stagger">
      <div class="revcard"><p>"They literally remember each student's name and welcome each one of us to class each day. Cobrinha and the instructors have created a training environment based on kindness, respect, hard work and world-class instruction."</p><footer>Google review · adult member</footer></div>
      <div class="revcard"><p>"The quality of instruction is absolutely second to none. The fundamentals class had 34 students with four instructors in addition to Cobrinha himself. Jiu jitsu at its very best."</p><footer>Google review · visiting black belt</footer></div>
      <div class="revcard"><p>"Not only can you level up your jiu jitsu game, you can level up your character. In my opinion, it is the best place you could bring your son or daughter to learn."</p><footer>Google review · parent</footer></div>
      <div class="revcard"><p>"Cobrinha himself stayed behind after class to answer technical questions from everyone, including the visitors. A friendly and welcoming environment with great training partners."</p><footer>Google review · visitor</footer></div>
    </div>
    <p class="muted rv small" style="margin-top:18px">Quotes are taken word for word from public Google reviews. Names are shown once each reviewer confirms.</p>
  </div>
</section>

<section class="mat">
  <div class="wrap">
    <p class="eyebrow rv">Go deeper</p>
    <h2 class="display rv">Everything else, one tap away.</h2>
    <div class="explore rv">
      <a href="/start/"><b>Your first month</b><span>What the first four weeks look like, step by step.</span></a>
      <a href="/kids/"><b>Kids</b><span>Ages 3 to 16, by age group, with the free trial times.</span></a>
      <a href="/pricing/"><b>Membership</b><span>8, 12 or unlimited classes a month, and the family plan.</span></a>
      <a href="/visit/"><b>Visit us</b><span>4929 Wilshire: parking, what to bring, what happens when you walk in.</span></a>
      <a href="/faq/"><b>Questions</b><span>Straight answers to everything people ask before their first class.</span></a>
    </div>
  </div>
</section>


<script>
window.SCHEDULE=[
{d:"Sun",t:"10:00 am",c:"All Levels · members only"},
{d:"Mon",t:"6:30 am",c:"All Levels · 3 stripes+"},{d:"Mon",t:"12:00 pm",c:"Advanced BJJ · blue belt+"},{d:"Mon",t:"4:10 pm",c:"Little Eagles"},{d:"Mon",t:"5:00 pm",c:"Eagle Warriors"},{d:"Mon",t:"6:10 pm",c:"Fundamentals 2 · 3 stripes+"},{d:"Mon",t:"6:10 pm",c:"Women's class"},{d:"Mon",t:"7:20 pm",c:"Advanced · blue belt+"},{d:"Mon",t:"8:00 pm",c:"Fundamentals 1 · all levels"},
{d:"Tue",t:"6:30 am",c:"Fundamentals 1 · all levels"},{d:"Tue",t:"8:00 am",c:"Women's class"},{d:"Tue",t:"12:00 pm",c:"No-Gi Advanced · blue belt+"},{d:"Tue",t:"4:10 pm",c:"Baby Eagles"},{d:"Tue",t:"5:00 pm",c:"Eagle Warriors"},{d:"Tue",t:"5:00 pm",c:"Eagle Teens"},{d:"Tue",t:"6:10 pm",c:"Fundamentals 1"},{d:"Tue",t:"6:10 pm",c:"No-Gi Fundamentals"},{d:"Tue",t:"7:20 pm",c:"No-Gi · 3 stripes+"},
{d:"Wed",t:"6:30 am",c:"All Levels · 3 stripes+"},{d:"Wed",t:"12:00 pm",c:"Advanced BJJ · blue belt+"},{d:"Wed",t:"4:10 pm",c:"Little Eagles"},{d:"Wed",t:"5:00 pm",c:"Eagle Warriors"},{d:"Wed",t:"6:10 pm",c:"Fundamentals 2 · 3 stripes+"},{d:"Wed",t:"6:10 pm",c:"Women's class"},{d:"Wed",t:"7:20 pm",c:"Advanced · blue belt+"},{d:"Wed",t:"8:00 pm",c:"Fundamentals 1 · all levels"},
{d:"Thu",t:"6:30 am",c:"Fundamentals 1 · all levels"},{d:"Thu",t:"12:00 pm",c:"No-Gi Advanced · blue belt+"},{d:"Thu",t:"4:10 pm",c:"Baby Eagles"},{d:"Thu",t:"5:00 pm",c:"Eagle Warriors"},{d:"Thu",t:"5:00 pm",c:"Eagle Teens"},{d:"Thu",t:"6:10 pm",c:"Fundamentals 1"},{d:"Thu",t:"6:10 pm",c:"No-Gi Fundamentals"},{d:"Thu",t:"7:20 pm",c:"No-Gi · 3 stripes+"},
{d:"Fri",t:"6:30 am",c:"All Levels · 3 stripes+"},{d:"Fri",t:"12:00 pm",c:"Advanced BJJ · blue belt+"},{d:"Fri",t:"4:10 pm",c:"Little Eagles"},{d:"Fri",t:"5:00 pm",c:"Eagle Warriors No-Gi · all levels"},{d:"Fri",t:"6:20 pm",c:"Fundamentals 2 · 4 stripes+"},
{d:"Sat",t:"9:00 am",c:"Eagle Warriors · all levels"},{d:"Sat",t:"10:00 am",c:"Capofit workout"},{d:"Sat",t:"11:15 am",c:"Fundamentals 3 · 4 stripes+"},{d:"Sat",t:"11:15 am",c:"Women's class"}
];
</script>

<!-- /wp:html -->
