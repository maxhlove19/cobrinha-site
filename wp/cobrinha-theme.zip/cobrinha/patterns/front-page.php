<?php
/**
 * Title: Alliance Jiu Jitsu Los Angeles by Cobrinha
 * Slug: cobrinha/front-page
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<header class="hero">
  <img class="hero-img" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/hero-mat.webp" alt="Cobrinha seated at the front of a full mat of students at the Los Angeles academy" fetchpriority="high">
  <div class="hero-in">
    <div class="hero-copy">
    <p class="eyebrow light">Brazilian Jiu-Jitsu · Wilshire &amp; Highland, Los Angeles</p>
    <div class="next" id="nextClass"><span class="dot"></span><span>Loading today's classes…</span></div>
    <h1 class="display">Train with a legend.<br><span class="thin">Start as a beginner.</span></h1>
    <p class="hero-badge">The only Super Grand Slam champion in history</p>
    <p class="lead">Led by Rubens "Cobrinha" Charles, five-time World Champion. Sixteen years on Wilshire. Your first class is free.</p>
    <div class="hero-actions">
      <a class="btn red big" href="/free-class/">Book a free class</a>
      <a class="btn ghost big" href="/schedule/">See the schedule</a>
    </div>
    <div class="chips">
      <span class="chip"><b>16</b> years on Wilshire</span>
      <span class="chip"><b><span class="star">★</span> 4.9</b> on Google</span>
      <span class="chip"><b>5×</b> World Champion head coach</span>
      <span class="chip"><b>Only</b> Super Grand Slam champion in history</span>
    </div>
    </div>
  </div>
</header>

<section class="dark proof">
  <div class="wrap proof-in">
    <div class="stat"><b><span data-count="16">0</span></b><span>Years on Wilshire</span></div>
    <div class="stat"><b><span data-count="5">0</span><i>×</i></b><span>IBJJF World Champion</span></div>
    <div class="stat"><b><span data-count="3">0</span><i>×</i></b><span>ADCC Champion</span></div>
    <div class="stat"><b><span data-count="4.9">0</span></b><span>Google rating, 200 reviews</span></div>
    <div class="stat"><b>Only<i> one </i>ever</b><span>Super Grand Slam champion</span></div>
  </div>
</section>

<div class="ticker" aria-hidden="true"><div class="ticker-in"><span>16 years on Wilshire</span><span>5× World Champion</span><span>3× ADCC Champion</span><span>Only Super Grand Slam champion ever</span><span>4.9★ on Google</span><span>Free first class</span><span>Kids from age 3</span><span>Women's program</span><span>No-Gi four days a week</span><span>16 years on Wilshire</span><span>5× World Champion</span><span>3× ADCC Champion</span><span>Only Super Grand Slam champion ever</span><span>4.9★ on Google</span><span>Free first class</span><span>Kids from age 3</span><span>Women's program</span><span>No-Gi four days a week</span></div></div>

<section class="mat">
  <div class="wrap">
    <div class="sec-head rv">
      <p class="eyebrow">Never trained? Start here.</p>
      <h2 class="display">Your first month, step by step.</h2>
      <p class="lead">Most people who walk in have never done a martial art. The path is simple and nobody is thrown in with the advanced class.</p>
    </div>
    <div class="steps rv stagger">
      <div class="step">
        <h3>Book a free class</h3>
        <p>Pick a time and tell us you're coming, so an instructor is ready for you. Sign the waiver online first; it creates your profile. Rent a gi at the desk.</p>
        <p class="when">Mon &amp; Wed 8 pm · Thu 6:10 pm</p>
      </div>
      <div class="step">
        <h3>Four-week Beginners course</h3>
        <p>Three classes a week built for people with zero experience: how to fall, how to stand up, how to escape, the first submissions. Taught by black and brown belts.</p>
        <p class="when">Mon &amp; Wed 8 pm · Thu 6:10 pm · start any week</p>
      </div>
      <div class="step">
        <h3>Join Fundamentals</h3>
        <p>After the course you move into Fundamentals 1 with people at your level, then earn your stripes toward Fundamentals 2 and the advanced room.</p>
        <p class="when">Every weekday, morning and evening</p>
      </div>
    </div>
    <p class="rv" style="margin-top:26px"><a class="btn line" href="/start/">Everything a beginner wants to know</a></p>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="finder rv" id="finder">
      <div>
        <p class="eyebrow light">Thirty seconds</p>
        <h3>Which class is right for you?</h3>
        <div class="fq" style="margin-top:18px">
          <p>Who is it for?</p>
          <div class="opts"><button class="opt" data-g="who" data-v="me" aria-pressed="true">Me</button><button class="opt" data-g="who" data-v="kid" aria-pressed="false">My child</button><button class="opt" data-g="who" data-v="woman" aria-pressed="false">Me · women-only class</button></div>
          <p>Experience</p>
          <div class="opts"><button class="opt" data-g="exp" data-v="none" aria-pressed="true">None</button><button class="opt" data-g="exp" data-v="some" aria-pressed="false">White belt · some</button><button class="opt" data-g="exp" data-v="blue" aria-pressed="false">Blue belt and up</button></div>
          <p>What you want</p>
          <div class="opts"><button class="opt" data-g="goal" data-v="fit" aria-pressed="true">Fitness &amp; self-defense</button><button class="opt" data-g="goal" data-v="comp" aria-pressed="false">Compete</button><button class="opt" data-g="goal" data-v="nogi" aria-pressed="false">No-Gi</button></div>
        </div>
      </div>
      <div class="fres" id="fres" aria-live="polite"></div>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="sec-head rv">
      <p class="eyebrow">Programs</p>
      <h2 class="display">A class for where you are.</h2>
    </div>
    <div class="prog rv stagger">
      <a class="pcard" href="/start/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/beginners.webp" alt="" loading="lazy"><div class="pin"><small>Adults · no experience</small><b>Beginners</b><span>Four-week course · start any week</span></div></a>
      <a class="pcard" href="/programs/#fundamentals"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-fundamentals.webp" alt="" loading="lazy"><div class="pin"><small>Adults · white to blue</small><b>Fundamentals</b><span>Levels 1, 2 and 3 by stripe</span></div></a>
      <a class="pcard" href="/programs/#advanced"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-nogi-win.webp" alt="" loading="lazy"><div class="pin"><small>Adults · blue belt and up</small><b>Advanced &amp; Competition</b><span>Cobrinha's room</span></div></a>
      <a class="pcard" href="/programs/#nogi"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-nogi-1.webp" alt="" loading="lazy"><div class="pin"><small>Adults · all levels</small><b>No-Gi</b><span>Six classes a week, Tuesday and Thursday</span></div></a>
      <a class="pcard" href="/womens/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-womens-1.webp" alt="" loading="lazy"><div class="pin"><small>Women only · black belt coach</small><b>Women's</b><span>Tue 8 am · Sat 11:15 am · free trial Wed 6:10 pm</span></div></a>
      <a class="pcard" href="/kids/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/kids-run.webp" alt="" loading="lazy"><div class="pin"><small>Ages 3–12</small><b>Kids · Eagles</b><span>Baby, Little and Warrior Eagles</span></div></a>
      <a class="pcard" href="/kids/#teens"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-kids-coach.webp" alt="" loading="lazy"><div class="pin"><small>Ages 13–16</small><b>Teens</b><span>Tue &amp; Thu 5 pm</span></div></a>
      <a class="pcard" href="/programs/#private"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/cobrinha.webp" alt="" loading="lazy"><div class="pin"><small>One on one</small><b>Private lessons</b><span>Black and brown belt instructors</span></div></a>
    </div>
  </div>
</section>

<section class="mat">
  <div class="wrap split">
    <div class="media wide rv l"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/kids-run.webp" alt="Six young students in gis running across the mat, laughing" loading="lazy"></div>
    <div class="rv">
      <p class="eyebrow">Kids &amp; teens · the Eagles program</p>
      <h2 class="display">Confidence they earn themselves.</h2>
      <p class="lead">Ages 3 to 16, grouped by age and level. Jiu-Jitsu is the safest martial art for a child to start: no punching, no kicking, and technique that lets a smaller kid control a bigger one.</p>
      <ul class="checks">
        <li>Real self-defense and a plan for bullies that starts with walking away</li>
        <li>Belts and stripes that give measurable goals a child can reach</li>
        <li>Respect on the mat that shows up at home and at school</li>
        <li>Coaches who know every child's name</li>
      </ul>
      <div class="strip">
        <div class="srow"><b>Baby Eagles · ages 3–4</b><span>Tue &amp; Thu 4:10 pm</span></div>
        <div class="srow"><b>Little Eagles · ages 5–6</b><span>Mon, Wed &amp; Fri 4:10 pm</span></div>
        <div class="srow"><b>Eagle Warriors · ages 7–12</b><span>Mon–Thu 5:00 pm · Sat 9 am</span></div>
        <div class="srow"><b>Eagle Teens · ages 13–16</b><span>Tue &amp; Thu 5:00 pm</span></div>
      </div>
      <a class="btn red" href="free-class.html?program=kids">Book a kids intro class</a>
    </div>
  </div>
</section>

<section class="dark" id="cobrinha">
  <div class="wrap split rev">
    <div class="media tall rv r"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/cobrinha.webp" alt="Rubens Cobrinha Charles in his Alliance gi, arms crossed, smiling" loading="lazy"></div>
    <div class="rv">
      <p class="eyebrow light">Head coach</p>
      <h2 class="display">Rubens "Cobrinha" Charles</h2>
      <p class="lead">The only black belt in history to win ADCC, the Worlds, the Pans, the Europeans and the Brazilian Nationals in a single year. He teaches on this mat every week, and he teaches beginners.</p>
      <div class="tl" id="tl" aria-label="Career timeline, tap a year">
        <button class="tli" data-d="Black belt from Fernando Tereré. Won the CBJJO World Championship the same year, then Pro Jiu-Jitsu X in Japan."><b>2005</b><span>Black belt</span></button>
        <button class="tli" data-d="First IBJJF World title at black belt, every opponent finished by submission. Titles followed in 2007, 2008 and 2009."><b>2006</b><span>World Champion</span></button>
        <button class="tli" data-d="IBJJF No-Gi World Champion in 2007 and 2008, again in 2011 and 2012."><b>2007</b><span>No-Gi Worlds</span></button>
        <button class="tli" data-d="Fourth straight IBJJF World title. Pan Champion 2007, 2008 and 2009."><b>2009</b><span>4th Worlds</span></button>
        <button class="tli" data-d="Opened Cobrinha Brazilian Jiu-Jitsu on Wilshire Boulevard, Los Angeles. Same corner ever since."><b>2010</b><span>Wilshire opens</span></button>
        <button class="tli" data-d="First ADCC World Championship gold, beating Rafael Mendes in the final. Won again in 2015 and 2017."><b>2013</b><span>ADCC gold</span></button>
        <button class="tli" data-d="The Super Grand Slam: Europeans, Pans, Brazilian Nationals, Worlds and ADCC in a single year. The only black belt in history to do it."><b>2017</b><span>Super Grand Slam</span></button>
        <button class="tli" data-d="IBJJF Hall of Fame and ADCC Hall of Fame. Voted Best Guard of the Decade by fellow world champions."><b>HOF</b><span>Hall of Fame</span></button>
      </div>
      <p class="tld" id="tld" aria-live="polite"></p>
      <p class="quote">"We don't just build competitors. We build champions for life."</p>
      <p class="muted">Cobrinha, to the kids' competition team</p>
      <a class="btn ghost" href="/instructors/" style="margin-top:14px">Meet all the instructors</a>
    </div>
  </div>
</section>

<section>
  <div class="wrap split">
    <div class="rv">
      <p class="eyebrow">Schedule</p>
      <h2 class="display" id="todayName">Today</h2>
      <p class="lead">Classes six days a week, 6:30 am to 9 pm, plus a members' open mat on Sunday morning. Trials are booked ahead so an instructor is ready for you. Beginners, Fundamentals, Advanced, No-Gi, Women's and Kids each have their own slots, so you're always training with your level.</p>
      <a class="btn line" href="/schedule/">Full weekly schedule</a>
    </div>
    <div class="dark rv" style="padding:26px;border-radius:4px">
      <div class="today" id="today"></div>
    </div>
  </div>
</section>

<section class="mat">
  <div class="wrap">
    <div class="sec-head rv">
      <p class="eyebrow">The academy</p>
      <h2 class="display">Inside 4929 Wilshire.</h2>
      <p class="lead">A full-size competition mat, a lounge for parents, changing rooms with showers, and a parking lot with validation. In the lobby of the building on the corner of Wilshire and Highland.</p>
    </div>
    <div class="gallery rv stagger">
      <figure><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/facility-1.webp" alt="Lounge area with black leather seating and the mat beyond" loading="lazy"></figure>
      <figure><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/facility-7.webp" alt="Framed championship photos and medals on the academy wall" loading="lazy"></figure>
      <figure><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/facility-2.webp" alt="The main training mat" loading="lazy"></figure>
      <figure><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/facility-4.webp" alt="Academy interior" loading="lazy"></figure>
    </div>
    <div class="facts rv stagger">
      <div class="fact"><b>7 days</b><span>classes Mon–Sat, open mat Sunday</span></div>
      <div class="fact"><b>Free parking</b><span>before 8:30 am, after 6 pm, weekends</span></div>
      <div class="fact"><b>Showers</b><span>men's and women's changing rooms</span></div>
      <div class="fact"><b>Loaner gis</b><span>for your first class</span></div>
    </div>
    <p class="rv" style="margin-top:26px"><a class="link" href="/visit/">Parking, uniform and what to expect on your first visit</a></p>
  </div>
</section>

<section class="dark" id="membership">
  <div class="wrap">
    <div class="sec-head rv">
      <p class="eyebrow light">Membership</p>
      <h2 class="display">One membership, the whole academy.</h2>
      <p class="lead">Try a class free first. Every plan includes the whole academy: gi, no-gi, every instructor, six days a week. Memberships renew monthly with 30 days' notice, and the desk walks you through the plans after your first class.</p>
    </div>
    <div class="plans rv up">
      <div class="plan" style="--i:0"><p class="plan-name">Silver</p><p class="plan-count">8<span>classes a month</span></p><p class="plan-per">Twice a week, any program</p></div>
      <div class="plan hot" style="--i:1"><p class="plan-name">Gold</p><p class="plan-count">12<span>classes a month</span></p><p class="plan-per">Three times a week</p></div>
      <div class="plan" style="--i:2"><p class="plan-name">Platinum</p><p class="plan-count">Unlimited<span>classes</span></p><p class="plan-per">Every day, gi and no-gi</p></div>
      <div class="plan" style="--i:3"><p class="plan-name">Kids &amp; teens</p><p class="plan-count">3–16<span>years old</span></p><p class="plan-per">Their age group · family discount</p></div>
    </div>
    </div>
    <p class="rv" style="margin-top:26px;display:flex;gap:12px;flex-wrap:wrap"><a class="btn red" href="/free-class/">Start with a free class</a><a class="btn ghost" href="/pricing/">Everything that's included</a></p>
  </div>
</section>

<section class="mat">
  <div class="wrap">
    <div class="sec-head rv">
      <p class="eyebrow">From the mat</p>
      <h2 class="display">This week, on Instagram.</h2>
      <p class="lead">Drills, kids classes and competition days, posted by the academy and our instructors. <a class="link" href="https://www.instagram.com/alliancecobrinha/" target="_blank" rel="noopener">Follow @alliancecobrinha</a>.</p>
    </div>
    <div class="grid-3 rv stagger">
      <blockquote class="instagram-media" data-instgrm-permalink="https://www.instagram.com/reel/DJfXq5xBn2c/" data-instgrm-version="14" style="margin:0;max-width:100%;min-width:0;background:#fff;border:1px solid var(--line);border-radius:4px"><a href="https://www.instagram.com/reel/DJfXq5xBn2c/" target="_blank" rel="noopener">Kids class drills · @alliancecobrinha</a></blockquote>
      <blockquote class="instagram-media" data-instgrm-permalink="https://www.instagram.com/reel/C8YdyOhxQ_j/" data-instgrm-version="14" style="margin:0;max-width:100%;min-width:0;background:#fff;border:1px solid var(--line);border-radius:4px"><a href="https://www.instagram.com/reel/C8YdyOhxQ_j/" target="_blank" rel="noopener">Fundamentals class drills · @alliancecobrinha</a></blockquote>
      <blockquote class="instagram-media" data-instgrm-permalink="https://www.instagram.com/reel/DQ24Ck2CZ_z/" data-instgrm-version="14" style="margin:0;max-width:100%;min-width:0;background:#fff;border:1px solid var(--line);border-radius:4px"><a href="https://www.instagram.com/reel/DQ24Ck2CZ_z/" target="_blank" rel="noopener">Women's self-defense · @uchavalverde</a></blockquote>
    </div>
    <script>(function(){var sec=document.currentScript.parentNode,done=false;function go(){if(done)return;done=true;var s=document.createElement("script");s.async=true;s.src="https://www.instagram.com/embed.js";document.body.appendChild(s);}if("IntersectionObserver" in window){new IntersectionObserver(function(e,o){if(e[0].isIntersecting){go();o.disconnect();}},{rootMargin:"600px"}).observe(sec);}else{go();}})();</script>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="sec-head rv">
      <p class="eyebrow">What students say</p>
      <h2 class="display">Rated 4.9 on Google.</h2>
    </div>
    <div class="rating rv">
      <b>4.9</b>
      <div><div class="stars" aria-label="4.9 out of 5 stars">★★★★★</div><div class="src">From 200 Google reviews · 4.7 on Yelp (120 reviews)</div></div>
      <a class="btn line" href="https://search.google.com/local/reviews?placeid=ChIJ9a1UHee4woARhGUPe_kWVfw" target="_blank" rel="noopener">Read the reviews</a>
    </div>
    <div class="grid-4 rv stagger">
      <div class="revcard"><p>"They literally remember each student's name and welcome each one of us to class each day. Cobrinha and the instructors have created a training environment based on kindness, respect, hard work and world-class instruction."</p><footer>Google review · adult member</footer></div>
      <div class="revcard"><p>"The quality of instruction is absolutely second to none. The fundamentals class had 34 students with four instructors in addition to Cobrinha himself. Jiu jitsu at its very best."</p><footer>Google review · visiting black belt</footer></div>
      <div class="revcard"><p>"Not only can you level up your jiu jitsu game, you can level up your character. In my opinion, it is the best place you could bring your son or daughter to learn."</p><footer>Google review · parent</footer></div>
      <div class="revcard"><p>"Cobrinha himself stayed behind after class to answer technical questions from everyone, including the visitors. A friendly and welcoming environment with great training partners."</p><footer>Google review · visitor</footer></div>
    </div>
    <p class="muted rv small" style="margin-top:18px">Quotes are taken word for word from public Google reviews. Names are shown once each reviewer confirms.</p>
  </div>
</section>

<section class="mat">
  <div class="wrap">
    <div class="sec-head rv">
      <p class="eyebrow">Questions beginners ask</p>
      <h2 class="display">Straight answers.</h2>
    </div>
    <div class="faq rv">
      <details><summary>I've never done any martial art. Will I be lost?</summary><div class="ans">No. Beginners start in a four-week course built for people with zero experience, then move into Fundamentals with others at the same level. Nobody spars in their first class unless they ask to.</div></details>
      <details><summary>Am I too old or too out of shape?</summary><div class="ans">We have students who started at 50 and 60. Jiu-Jitsu is technique and leverage, not strength, and the pace of the beginners course is set by the room. Fitness comes from the training, not before it.</div></details>
      <details><summary>What do I wear to the first class?</summary><div class="ans">Comfortable athletic clothes; rent a gi at the desk for the trial ($20, refunded when you sign up). Members train in a blue or white Alliance or Cobrinha gi, so the whole room looks like one team. If you continue, you'll train in an academy gi (white or blue) with a rash guard underneath.</div></details>
      <details><summary>Is it safe? Will I get hurt?</summary><div class="ans">Jiu-Jitsu has no striking. Beginners drill techniques with a partner under a coach's eye, and every roll ends the moment someone taps. Injuries are far rarer than in most team sports.</div></details>
      <details><summary>How much does it cost?</summary><div class="ans">The first class is free (gear rental $20 adults, $15 kids, refunded when you sign up). Memberships renew monthly with 30 days' notice, from eight classes a month to unlimited, with a family discount for the second family member onward. The desk goes through the plans with you after your first class. <a class="link" href="/pricing/">See membership</a>.</div></details>
      <details><summary>Where do I park?</summary><div class="ans">The building lot, with validation: free before 8:30 am, after 6 pm and on weekends, $5 for two hours midday. Free street parking on Highland Ave.</div></details>
      <details><summary>Can my child start at 3?</summary><div class="ans">Yes. Baby Eagles is for ages 3–4, twice a week. Little Eagles is 5–6, Eagle Warriors is 7–12, and Teens is 13–16. Trials for the little ones are 30 minutes at 3:30 pm.</div></details>
      <details><summary>I already train. Can I drop in?</summary><div class="ans">Yes. Drop-ins with experience are $60 a class with a gi included, and the $60 is refunded if you sign up. Call or email ahead so we can reserve your spot. Everyone on the mat wears a blue or white Alliance or Cobrinha gi; we keep everyone one team. Cobrinha's advanced class is blue belt and up.</div></details>
    </div>
    <p class="rv" style="margin-top:22px"><a class="btn line" href="/faq/">All questions and answers</a></p>
  </div>
</section>

<script>
window.SCHEDULE=[
{d:"Mon",t:"6:30 am",c:"Fundamentals 2 · 3 stripes+"},{d:"Mon",t:"12:00 pm",c:"Advanced BJJ · blue belt+"},{d:"Mon",t:"3:30 pm",c:"Kids free trial · ages 5–6"},{d:"Mon",t:"4:10 pm",c:"Little Eagles · ages 5–6"},{d:"Mon",t:"5:00 pm",c:"Eagle Warriors · ages 7–12"},{d:"Mon",t:"6:10 pm",c:"Fundamentals 2"},{d:"Mon",t:"7:20 pm",c:"Advanced · blue belt+"},{d:"Mon",t:"8:00 pm",c:"Fundamentals 1 · all levels"},
{d:"Tue",t:"6:30 am",c:"Fundamentals 1 · all levels"},{d:"Tue",t:"8:00 am",c:"Women's class"},{d:"Tue",t:"12:00 pm",c:"No-Gi Advanced · blue belt+"},{d:"Tue",t:"3:30 pm",c:"Kids free trial · ages 3–4"},{d:"Tue",t:"4:10 pm",c:"Baby Eagles · ages 3–4"},{d:"Tue",t:"5:00 pm",c:"Eagle Warriors · ages 7–12 & Teens"},{d:"Tue",t:"6:10 pm",c:"Fundamentals 1 · No-Gi Fundamentals · Women's free trial"},{d:"Tue",t:"7:20 pm",c:"No-Gi · 3 stripes+"},
{d:"Wed",t:"6:30 am",c:"Fundamentals 2 · 3 stripes+"},{d:"Wed",t:"12:00 pm",c:"Advanced BJJ · blue belt+"},{d:"Wed",t:"3:30 pm",c:"Kids free trial · ages 5–6"},{d:"Wed",t:"4:10 pm",c:"Little Eagles · ages 5–6"},{d:"Wed",t:"5:00 pm",c:"Eagle Warriors · ages 7–12"},{d:"Wed",t:"6:10 pm",c:"Fundamentals 2 · Women's free trial"},{d:"Wed",t:"7:20 pm",c:"Advanced · blue belt+"},{d:"Wed",t:"8:00 pm",c:"Fundamentals 1 · all levels"},
{d:"Thu",t:"6:30 am",c:"All Levels · 3 stripes+"},{d:"Thu",t:"12:00 pm",c:"No-Gi Advanced · blue belt+"},{d:"Thu",t:"3:30 pm",c:"Kids free trial · ages 3–4"},{d:"Thu",t:"4:10 pm",c:"Baby Eagles · ages 3–4"},{d:"Thu",t:"5:00 pm",c:"Eagle Warriors · ages 7–12 & Teens"},{d:"Thu",t:"6:10 pm",c:"Fundamentals 1 · No-Gi Fundamentals · Women's free trial"},{d:"Thu",t:"7:20 pm",c:"No-Gi · 3 stripes+"},
{d:"Fri",t:"6:30 am",c:"Conditioning, then rolling"},{d:"Fri",t:"12:00 pm",c:"Advanced BJJ · blue belt+"},{d:"Fri",t:"4:10 pm",c:"Little Eagles · ages 5–6"},{d:"Fri",t:"5:00 pm",c:"Eagle Warriors No-Gi · all levels"},{d:"Fri",t:"6:20 pm",c:"Fundamentals 2 · 4 stripes+"},
{d:"Sat",t:"9:00 am",c:"Eagle Warriors · all levels"},{d:"Sat",t:"10:00 am",c:"Capofit workout"},{d:"Sat",t:"11:15 am",c:"Fundamentals 3 · Women's class"},
{d:"Sun",t:"10:00 am",c:"Open mat · all levels · members only"}
];
</script>

<!-- /wp:html -->
