<?php
/**
 * Title: Contact
 * Slug: cobrinha/contact
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="phero">
  <div class="wrap">
    <p class="crumbs"><a href="/">Home</a> / Contact</p>
    <p class="eyebrow">Contact</p>
    <h1 class="display">Talk to a person.</h1>
    <p class="lead">Call or text (323) 931-9953; during class hours the front desk picks up. Email and we reply the same day. Or just come in; the desk is open whenever classes are running.</p>
    <div class="hero-actions" style="margin-top:22px"><a class="btn red big" href="tel:+13239319953">Call (323) 931-9953</a><a class="btn ghost big" href="sms:+13239319953">Text us</a><a class="btn ghost big" href="/free-class/">Book a free class</a></div>
  </div>
</section>

<section>
  <div class="wrap grid-2">
    <form class="form rv l" id="bookForm" method="post" action="https://formsubmit.co/info@cobrinhabjj.com" novalidate>
      <input type="hidden" name="_subject" value="Website message — cobrinhabjj.com">
      <input type="hidden" name="_next" value="{{thanks}}">
      <input type="hidden" name="_captcha" value="false">
      <input type="text" name="_honey" style="display:none" tabindex="-1" autocomplete="off">
      <p class="label">Send a message</p>
      <div class="row">
        <label>Your name <input type="text" name="name" autocomplete="name" required></label>
        <label>Phone <input type="tel" name="phone" autocomplete="tel" inputmode="tel"></label>
      </div>
      <label>Email <input type="email" name="email" autocomplete="email" required></label>
      <label>What is it about? <select name="program">
        <option>Free class for me</option><option>Free class for my child</option><option>Women's program</option><option>Private lessons</option><option>Visiting / drop-in</option><option>Membership question</option><option>Something else</option>
      </select></label>
      <label>Message <textarea name="notes" rows="5" required></textarea></label>
      <button class="btn red big" type="submit">Send</button>
      <p class="fine">We reply by email or text the same day.</p>
    </form>
    <div class="rv">
      <p class="label">Address</p>
      <p class="lead" style="margin-bottom:6px">4929 Wilshire Blvd, Suite 104<br>Los Angeles, CA 90010</p>
      <p class="muted">Corner of Wilshire &amp; Highland, Hancock Park. The academy is in the building lobby; parking in the building lot with validation.</p>
      <p><a class="link" href="https://maps.google.com/?q=4929+Wilshire+Blvd+%23104+Los+Angeles+CA+90010" target="_blank" rel="noopener">Open in Google Maps</a></p>
      <div style="aspect-ratio:4/3;border-radius:4px;overflow:hidden;background:var(--mat);margin:18px 0">
        <iframe title="Map to Alliance Jiu Jitsu Los Angeles" src="https://www.google.com/maps?q=4929+Wilshire+Blvd+%23104,+Los+Angeles,+CA+90010&output=embed" width="100%" height="100%" style="border:0" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
      </div>
      <p class="label">Phone &amp; email</p>
      <p><a class="link" href="tel:+13239319953">(323) 931-9953</a> · <a class="link" href="mailto:info@cobrinhabjj.com">info@cobrinhabjj.com</a></p>
      <p class="label" style="margin-top:18px">Class hours</p>
      <p>Mon–Fri 6:30 am – 9:00 pm · Sat 9:00 am – 12:15 pm · Sun 10 am members' open mat</p>
      <p class="label" style="margin-top:18px">Follow</p>
      <p><a class="link" href="https://www.instagram.com/alliancecobrinha/" target="_blank" rel="noopener">Instagram</a> · <a class="link" href="https://www.facebook.com/CobrinhaBJJ" target="_blank" rel="noopener">Facebook</a> · <a class="link" href="https://www.youtube.com/user/Cobrinhabjj" target="_blank" rel="noopener">YouTube</a></p>
    </div>
  </div>
</section>

<!-- /wp:html -->
