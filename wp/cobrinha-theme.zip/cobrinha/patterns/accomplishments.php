<?php
/**
 * Title: Cobrinha's competition record
 * Slug: cobrinha/accomplishments
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="phero">
  <div class="wrap">
    <p class="crumbs"><a href="/">Home</a> / <a href="/academy/">Academy</a> / Accomplishments</p>
    <p class="eyebrow">Rubens "Cobrinha" Charles</p>
    <h1 class="display">The record.</h1>
    <p class="lead">Twelve world titles in the gi, in no-gi and at ADCC, and one year nobody had ever had before. Every result on this page is listed with the division it was won in.</p>
  </div>
</section>

<section class="dark proof">
  <div class="wrap proof-in">
    <div class="stat"><b>5<i>&times;</i></b><span>IBJJF World Champion</span></div>
    <div class="stat"><b>4<i>&times;</i></b><span>No-Gi World Champion</span></div>
    <div class="stat"><b>3<i>&times;</i></b><span>ADCC World Champion</span></div>
    <div class="stat"><b>5<i>&times;</i></b><span>IBJJF Pan Champion</span></div>
    <div class="stat"><b>1<i>&times;</i></b><span>IBJJF European Champion</span></div>
  </div>
</section>

<section class="mat">
  <div class="wrap split">
    <div class="rv">
      <p class="eyebrow">2017</p>
      <h2 class="display">The Super Grand Slam.</h2>
      <p class="lead">Five majors exist in Brazilian Jiu-Jitsu. In 2017, at 37 years old, Cobrinha won all five of them in the same year — something no one had done before him.</p>
      <p>Every one of these five golds is confirmed in the IBJJF's own championship database or in the ADCC event record. He beat a different finalist in each.</p>
      <a class="btn line" href="/start/">Train where he teaches</a>
    </div>
    <div class="rv">
      <div class="strip" style="margin:0">
        <div class="srow"><b>IBJJF European Championship</b><span>Gold &middot; def. Gianni Grippo</span></div>
        <div class="srow"><b>IBJJF Pan American Championship</b><span>Gold &middot; def. Osvaldo "Queixinho" Moizinho</span></div>
        <div class="srow"><b>Brazilian National Championship</b><span>Gold &middot; def. Rafael Mansur</span></div>
        <div class="srow"><b>IBJJF World Championship</b><span>Gold &middot; def. Leonardo "Cascão" Saggioro</span></div>
        <div class="srow"><b>ADCC World Championship</b><span>Gold &middot; def. AJ Agazarm</span></div>
      </div>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="sec-head rv">
      <p class="eyebrow">Every result</p>
      <h2 class="display">Year by year.</h2>
      <p class="lead">Black belt from 2006 onward, at featherweight in the gi and at 66&nbsp;kg at ADCC. <strong>1st</strong> is gold, <strong>2nd</strong> silver, <strong>3rd</strong> bronze, <strong>HOF</strong> a Hall of Fame induction.</p>
    </div>

    <div class="rv" style="margin-bottom:38px">
      <h3 class="display" style="display:inline-block;border-bottom:3px solid var(--gold);padding-bottom:8px">2022</h3>
      <ul class="titles">
        <li><b>HOF</b><span>ADCC Hall of Fame — tenth inductee of the inaugural class, announced January 2022.</span></li>
      </ul>
    </div>

    <div class="rv" style="margin-bottom:38px">
      <h3 class="display" style="display:inline-block;border-bottom:3px solid var(--gold);padding-bottom:8px">2017</h3>
      <ul class="titles">
        <li><b>1st</b><span>IBJJF European Championship — black belt, featherweight (70&nbsp;kg), gi. Beat Gianni Grippo in the final.</span></li>
        <li><b>1st</b><span>IBJJF Pan American Championship — black belt, featherweight, gi. Beat Osvaldo "Queixinho" Moizinho in the final.</span></li>
        <li><b>1st</b><span>Brazilian National Championship (Brasileiro) — black belt, featherweight, gi. Beat Rafael Mansur in the final.</span></li>
        <li><b>1st</b><span>IBJJF World Championship — black belt, featherweight, gi. Beat Leonardo "Cascão" Saggioro in the final.</span></li>
        <li><b>1st</b><span>ADCC World Championship, Espoo, Finland — 66&nbsp;kg. Beat AJ Agazarm in the final.</span></li>
      </ul>
    </div>

    <div class="rv" style="margin-bottom:38px">
      <h3 class="display" style="display:inline-block;border-bottom:3px solid var(--gold);padding-bottom:8px">2015</h3>
      <ul class="titles">
        <li><b>1st</b><span>ADCC World Championship, São Paulo — 66&nbsp;kg. Beat Bruno Frazatto 3–0 in the final.</span></li>
      </ul>
    </div>

    <div class="rv" style="margin-bottom:38px">
      <h3 class="display" style="display:inline-block;border-bottom:3px solid var(--gold);padding-bottom:8px">2014</h3>
      <ul class="titles">
        <li><b>HOF</b><span>IBJJF Hall of Fame — inaugural induction class.</span></li>
      </ul>
    </div>

    <div class="rv" style="margin-bottom:38px">
      <h3 class="display" style="display:inline-block;border-bottom:3px solid var(--gold);padding-bottom:8px">2013</h3>
      <ul class="titles">
        <li><b>1st</b><span>ADCC World Championship, Beijing — 66&nbsp;kg. Beat Rafael Mendes on points in the final.</span></li>
      </ul>
    </div>

    <div class="rv" style="margin-bottom:38px">
      <h3 class="display" style="display:inline-block;border-bottom:3px solid var(--gold);padding-bottom:8px">2012</h3>
      <ul class="titles">
        <li><b>1st</b><span>IBJJF No-Gi World Championship — black belt, featherweight. Beat Justin Rader in the final.</span></li>
        <li><b>2nd</b><span>IBJJF Pan American Championship — black belt, featherweight, gi. Lost the final to Rafael Mendes.</span></li>
      </ul>
    </div>

    <div class="rv" style="margin-bottom:38px">
      <h3 class="display" style="display:inline-block;border-bottom:3px solid var(--gold);padding-bottom:8px">2011</h3>
      <ul class="titles">
        <li><b>1st</b><span>IBJJF No-Gi World Championship — black belt, featherweight.</span></li>
        <li><b>2nd</b><span>ADCC World Championship, Nottingham — 66&nbsp;kg. Lost the final to Rafael Mendes.</span></li>
        <li><b>2nd</b><span>World Professional Jiu-Jitsu Cup, Abu Dhabi — black belt, absolute (open weight). Lost the final to Rodolfo Vieira.</span></li>
        <li><b>3rd</b><span>IBJJF World Championship — black belt, featherweight, gi.</span></li>
        <li><b>3rd</b><span>World Professional Jiu-Jitsu Cup, Abu Dhabi — black belt, 74&nbsp;kg.</span></li>
      </ul>
    </div>

    <div class="rv" style="margin-bottom:38px">
      <h3 class="display" style="display:inline-block;border-bottom:3px solid var(--gold);padding-bottom:8px">2010</h3>
      <ul class="titles">
        <li><b>1st</b><span>IBJJF Pan American Championship — black belt, featherweight, gi.</span></li>
        <li><b>2nd</b><span>IBJJF World Championship — black belt, featherweight, gi.</span></li>
        <li><b>2nd</b><span>Brazilian National Championship (Brasileiro) — black belt, featherweight, gi.</span></li>
      </ul>
    </div>

    <div class="rv" style="margin-bottom:38px">
      <h3 class="display" style="display:inline-block;border-bottom:3px solid var(--gold);padding-bottom:8px">2009</h3>
      <ul class="titles">
        <li><b>1st</b><span>IBJJF World Championship — black belt, featherweight, gi.</span></li>
        <li><b>1st</b><span>IBJJF Pan American Championship — black belt, featherweight, gi.</span></li>
        <li><b>2nd</b><span>ADCC World Championship, Barcelona — 66&nbsp;kg. Lost the final to Rafael Mendes.</span></li>
        <li><b>3rd</b><span>IBJJF Pan American Championship — black belt, open class (absolute).</span></li>
      </ul>
    </div>

    <div class="rv" style="margin-bottom:38px">
      <h3 class="display" style="display:inline-block;border-bottom:3px solid var(--gold);padding-bottom:8px">2008</h3>
      <ul class="titles">
        <li><b>1st</b><span>IBJJF World Championship — black belt, featherweight, gi.</span></li>
        <li><b>1st</b><span>IBJJF No-Gi World Championship — black belt, lightweight. Won a division above his own.</span></li>
        <li><b>1st</b><span>IBJJF Pan American Championship — black belt, featherweight, gi.</span></li>
        <li><b>1st</b><span>IBJJF Pan American No-Gi Championship — black belt, lightweight.</span></li>
      </ul>
    </div>

    <div class="rv" style="margin-bottom:38px">
      <h3 class="display" style="display:inline-block;border-bottom:3px solid var(--gold);padding-bottom:8px">2007</h3>
      <ul class="titles">
        <li><b>1st</b><span>IBJJF World Championship — black belt, featherweight, gi.</span></li>
        <li><b>1st</b><span>IBJJF No-Gi World Championship — black belt, featherweight.</span></li>
        <li><b>1st</b><span>IBJJF Pan American Championship — black belt, featherweight, gi.</span></li>
      </ul>
    </div>

    <div class="rv" style="margin-bottom:38px">
      <h3 class="display" style="display:inline-block;border-bottom:3px solid var(--gold);padding-bottom:8px">2006</h3>
      <ul class="titles">
        <li><b>1st</b><span>IBJJF World Championship — black belt, featherweight, gi. His first world title as a black belt, one year after the promotion.</span></li>
      </ul>
    </div>

    <div class="rv" style="margin-bottom:38px">
      <h3 class="display" style="display:inline-block;border-bottom:3px solid var(--gold);padding-bottom:8px">2005</h3>
      <ul class="titles">
        <li><b>1st</b><span>Brazilian National Championship (Brasileiro) — brown belt, featherweight. Won in the year he took his black belt from Fernando "Tereré" Augusto.</span></li>
      </ul>
    </div>
  </div>
</section>

<section class="mat">
  <div class="wrap">
    <div class="sec-head rv">
      <p class="eyebrow">About this list</p>
      <h2 class="display">Checked, not copied.</h2>
    </div>
    <div class="grid-3 rv" style="counter-reset:s">
      <div class="step">
        <h3>Sourced from the federations</h3>
        <p>Results come from the IBJJF's own published results and championship database, and from ADCC event reports. Not from summaries and not from bios written elsewhere.</p>
      </div>
      <div class="step">
        <h3>Left off where it is thin</h3>
        <p>Placings we could not confirm in the federation's own database are left off.</p>
      </div>
      <div class="step">
        <h3>Nothing rounded up</h3>
        <p>Twelve world titles: five IBJJF World Championships, four No-Gi World Championships, three ADCC World Championships. Claims we could not verify are not on this page.</p>
      </div>
    </div>
    <p class="small muted rv" style="margin-top:22px">His last verified competition is ADCC 2017. If you know of a result that is missing or wrong, tell the front desk and we will check it.</p>
    <p class="rv" style="margin-top:22px"><a class="btn line" href="/instructors/">Meet the instructors</a></p>
  </div>
</section>

<!-- /wp:html -->
