<?php
/**
 * Title: Kids Brazilian Jiu-Jitsu in Los Angeles, ages 3–16
 * Slug: cobrinha/kids
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="phero img">
  <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/kids-run.webp" alt="" aria-hidden="true">
  <div class="wrap">
    <p class="crumbs"><a href="/">Home</a> / Kids &amp; teens</p>
    <p class="eyebrow">Ages 3–16 · the Eagles program</p>
    <h1 class="display">Kids who can<br>look after themselves.</h1>
    <p class="lead">Confidence, discipline and respect aren't things you can talk into a child. On the mat they earn them, one stripe at a time.</p>
    <div class="hero-actions" style="margin-top:22px"><a class="btn red big" href="free-class.html?program=kids">Book a kids intro class</a><a class="btn ghost big" href="#schedule">Class times</a></div>
  </div>
</section>

<section class="mat">
  <div class="wrap grid-2" style="align-items:center">
    <div class="rv l">
      <p class="eyebrow">Find their class in two seconds</p>
      <h2 class="display">How old is your child?</h2>
      <p class="lead">Slide to their age and we'll show the group, the class times and the free trial slot.</p>
    </div>
    <div class="agep rv r">
      <label for="age">Age</label>
      <div class="ageout"><b id="ageOut">6</b><span>years old</span></div>
      <input type="range" id="age" min="2" max="17" value="6" step="1" aria-label="Child's age">
      <div class="agres" id="ageRes" aria-live="polite"></div>
      <a class="btn red" href="free-class.html?program=kids">Book the free trial</a>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="sec-head rv">
      <p class="eyebrow">Four groups, by age and level</p>
      <h2 class="display">Where your child fits.</h2>
    </div>
    <div class="grid-4 rv stagger">
      <div class="step"><h3>Baby Eagles</h3><p><b>Ages 3–4.</b> Short classes built on games: balance, falling safely, listening, taking turns. Tuesday and Thursday 4:10 pm. <b>Free trial:</b> Tue or Thu 3:30 pm, 30 minutes.</p></div>
      <div class="step"><h3>Little Eagles</h3><p><b>Ages 5–6.</b> First real techniques, always as a game. Monday, Wednesday and Friday 4:10 pm. <b>Free trial:</b> Mon or Wed 3:30 pm, 30 minutes.</p></div>
      <div class="step"><h3>Eagle Warriors</h3><p><b>Ages 7–12, levels 1–4.</b> The full curriculum with stripes and belts. Monday to Thursday 5:00 pm, Friday No-Gi 5:00 pm, Saturday 9:00 am. <b>Free trial:</b> any Mon–Thu 5:00 pm.</p></div>
      <div class="step"><h3>Eagle Teens</h3><p><b>Ages 13–16.</b> Teen-only class that bridges into the adult program. Tuesday and Thursday 5:00 pm. <b>Free trial:</b> Tue or Thu 5:00 pm.</p></div>
    </div>
  </div>
</section>

<section class="mat">
  <div class="wrap split rev">
    <div class="media tall rv l"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-kids-blue.webp" alt="A young student in a blue gi working through a balance drill" loading="lazy"></div>
    <!-- Vimeo 881316304 (kids video) is restricted to the cobrinhabjj.com domain; swap back in once the site is on that domain. -->
    <div class="rv">
      <p class="eyebrow">A message to parents</p>
      <h2 class="display">Why Jiu-Jitsu, not another sport.</h2>
      <p class="lead">Everyone promises self-discipline, self-control and self-confidence. The honest question is how you give those to a child. Our answer: an environment of positive reinforcement, goals they can measure, respect they practice every class, and coaches who stay by their side.</p>
      <ul class="checks">
        <li><b>Safest martial art to start.</b> No punching or kicking. Technique lets a smaller child control a bigger one, so the training itself is gentle.</li>
        <li><b>Bully-proofing that starts with words.</b> Walk away first. If it can't be avoided, know exactly what to do.</li>
        <li><b>Goals they can reach.</b> Stripes every few months, belts by level. A child sees their own progress.</li>
        <li><b>Respect that travels.</b> Bow on, bow off, shake hands, listen. Parents tell us it shows up at the dinner table.</li>
        <li><b>Coordination and focus.</b> Balance, body awareness and attention that carry into every other sport and into school.</li>
        <li><b>Fun.</b> Half of every class is games. They're kids.</li>
      </ul>
    </div>
  </div>
</section>

<section id="schedule">
  <div class="wrap grid-2">
    <div class="rv">
      <p class="eyebrow">Kids schedule</p>
      <h2 class="display">Every weekday afternoon and Saturday morning.</h2>
      <p class="lead">Classes are short for the youngest and an hour for Warriors and Teens. Parents watch from the lounge. The trial is free and one-on-one with an instructor, so book ahead and sign the waiver online first. Gear rental is $15, refunded in full if your child signs up.</p>
      <div style="display:flex;gap:12px;flex-wrap:wrap"><a class="btn red" href="free-class.html?program=kids">Book a kids intro class</a><a class="btn line" href="tel:+13239319953">Come watch a class first</a></div>
      <p class="small muted" style="margin-top:12px">Not ready to book? Come and watch any 5 pm class from the lounge, no sign-up needed. Call ahead so we know to expect you.</p>
    </div>
    <div class="sched-wrap rv">
      <table class="sched">
        <thead><tr><th>Day</th><th>Time</th><th>Class</th></tr></thead>
        <tbody>
          <tr><td class="d">Mon</td><td class="t">4:10 pm</td><td>Little Eagles · 5–6</td></tr>
          <tr><td class="d">Mon</td><td class="t">5:00 pm</td><td>Eagle Warriors · 7–12</td></tr>
          <tr><td class="d">Tue</td><td class="t">4:10 pm</td><td>Baby Eagles · 3–4</td></tr>
          <tr><td class="d">Tue</td><td class="t">5:00 pm</td><td>Eagle Warriors · 7–12 &nbsp;·&nbsp; Eagle Teens · 13–16</td></tr>
          <tr><td class="d">Wed</td><td class="t">4:10 pm</td><td>Little Eagles · 5–6</td></tr>
          <tr><td class="d">Wed</td><td class="t">5:00 pm</td><td>Eagle Warriors · 7–12</td></tr>
          <tr><td class="d">Thu</td><td class="t">4:10 pm</td><td>Baby Eagles · 3–4</td></tr>
          <tr><td class="d">Thu</td><td class="t">5:00 pm</td><td>Eagle Warriors · 7–12 &nbsp;·&nbsp; Eagle Teens · 13–16</td></tr>
          <tr><td class="d">Fri</td><td class="t">4:10 pm</td><td>Little Eagles · 5–6</td></tr>
          <tr><td class="d">Fri</td><td class="t">5:00 pm</td><td>Eagle Warriors No-Gi · all levels</td></tr>
          <tr><td class="d">Sat</td><td class="t">9:00 am</td><td>Eagle Warriors · all levels</td></tr>
        </tbody>
      </table>
    </div>
  </div>
</section>

<section class="dark" id="teens">
  <div class="wrap split">
    <div class="media wide rv"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/kids-medal.webp" alt="Young competitor with a medal at a tournament" loading="lazy"></div>
    <div class="rv">
      <p class="eyebrow light">Competition team</p>
      <h2 class="display">For the kids who want more.</h2>
      <p class="lead">Competition is never required. For the children who ask, we're rebuilding a kids' competition team with quality, discipline and purpose, coached the way Cobrinha coached world champions.</p>
      <p class="quote">"We don't just build competitors. We build champions for life."</p>
      <p class="muted">Cobrinha</p>
    </div>
  </div>
</section>

<section class="mat">
  <div class="wrap">
    <div class="sec-head rv"><p class="eyebrow">Parents ask</p><h2 class="display">Good questions.</h2></div>
    <div class="faq rv">
      <details><summary>What does my child wear to the trial class?</summary><div class="ans">Comfortable clothes they can move in. Gi rental for the trial is $15, refunded in full when they sign up. Long hair tied back, no jewelry, nails trimmed.</div></details>
      <details><summary>Can I watch?</summary><div class="ans">Yes. The lounge looks onto the mat. For the youngest we ask parents to stay for the first few classes.</div></details>
      <details><summary>How much is the kids program?</summary><div class="ans">$257 a month. Family pricing is available when siblings or parents train; ask at the desk after the trial.</div></details>
      <details><summary>My child is shy. Will they be pushed?</summary><div class="ans">They'll be invited, not pushed. Coaches partner shy kids with patient ones and let them join at their pace. Most are on the mat by the second class.</div></details>
      <details><summary>How often should they come?</summary><div class="ans">Twice a week is ideal for the little ones; Warriors and Teens can train up to five days.</div></details>
    </div>
  </div>
</section>

<!-- /wp:html -->
