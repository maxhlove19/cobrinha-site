<?php
/**
 * Title: The academy
 * Slug: cobrinha/academy
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="phero img">
  <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/hero-mat.webp" alt="" aria-hidden="true">
  <div class="wrap">
    <p class="crumbs"><a href="/">Home</a> / Academy</p>
    <p class="eyebrow">Since 2010</p>
    <h1 class="display balance">Schools come and go. We've been here 16 years.</h1>
    <p class="lead">Same corner, same head coach, hundreds of students who started as white belts and are still on the mat.</p>
  </div>
</section>

<section>
  <div class="wrap split">
    <div class="rv">
      <p class="eyebrow">What we are</p>
      <h2 class="display">A world champion's academy that teaches beginners.</h2>
      <p class="lead">Cobrinha opened the academy on Wilshire Boulevard in 2010, a year after moving to Los Angeles at the height of his competition career. It has been the same thing ever since: a place where the best in the world train next to people on their first day, and where the standard is set by the man teaching the class.</p>
      <p>We are part of the Alliance Jiu-Jitsu team, the most successful team in the history of the sport, and the academy has produced champions at every belt from kids to black belt. Most of our students, though, are not competitors. They are people who wanted to get fit, feel safe, or give their child something real, and found a room that took them seriously.</p>
    </div>
    <div class="media wide rv r"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/hero-mat.webp" alt="The full academy seated on the mat" loading="lazy"></div>
  </div>
</section>

<section class="dark proof">
  <div class="wrap proof-in">
    <div class="stat"><b>2010</b><span>Opened on Wilshire</span></div>
    <div class="stat"><b>15<i>×</i></b><span>World Champion team (Alliance)</span></div>
    <div class="stat"><b>13</b><span>World titles held by the head coach</span></div>
    <div class="stat"><b>3–70</b><span>Age range on our mats</span></div>
    <div class="stat"><b>4.9</b><span>Google rating</span></div>
  </div>
</section>

<section class="mat">
  <div class="wrap split rev">
    <div class="media tall rv l"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/cobrinha.webp" alt="Rubens Cobrinha Charles" loading="lazy"></div>
    <div class="rv">
      <p class="eyebrow">Head coach</p>
      <h2 class="display">Rubens "Cobrinha" Charles Maciel</h2>
      <p class="lead">Born in Londrina, Brazil, in 1979. A capoeira practitioner who walked into a Jiu-Jitsu class at 21, took his black belt from Fernando "Tereré" Augusto in 2005 and won the World Championship that same year at brown belt, then the black belt title the next.</p>
      <p>Considered by many the best featherweight in the history of the sport. In 2017 he became the first and only black belt to win ADCC, the World Championship, the Pan Championship, the European Championship and the Brazilian Nationals in a single year. His guard was voted "Best Guard of the Decade" by fellow world champions. He is a member of both the IBJJF and ADCC Halls of Fame, and he has coached world champions including Michael Langhi and Sérgio Moraes, and MMA fighters including Fabricio Werdum and Cris Cyborg.</p>
      <ul class="titles">
        <li><b>5×</b><span>IBJJF World Champion — 2006, 2007, 2008, 2009, 2017</span></li>
        <li><b>4×</b><span>IBJJF No-Gi World Champion — 2007, 2008, 2011, 2012</span></li>
        <li><b>3×</b><span>ADCC World Champion — 2013, 2015, 2017</span></li>
        <li><b>4×</b><span>IBJJF Pan Champion · 2× European Champion · Brazilian Nationals Champion</span></li>
        <li><b>2017</b><span>Super Grand Slam — the only black belt in history</span></li>
      </ul>
      <a class="btn line" href="/instructors/">All instructors</a>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="sec-head rv"><p class="eyebrow">How we teach</p><h2 class="display">The method.</h2></div>
    <div class="grid-3 rv stagger">
      <div class="step"><h3>Levels, not luck</h3><p>Beginners, Fundamentals 1–3, Advanced. Stripes move you up. You always train with people at your level and a coach who knows what you should be working on.</p></div>
      <div class="step"><h3>Self-defense underneath everything</h3><p>The curriculum starts from the situations that actually happen, then builds the sport on top. A blue belt from this academy can protect themselves.</p></div>
      <div class="step"><h3>Champions teach</h3><p>Cobrinha teaches the advanced room every week and sets the curriculum for every level. Every class is led by a black or brown belt he promoted.</p></div>
    </div>
  </div>
</section>

<section class="mat">
  <div class="wrap">
    <div class="sec-head rv"><p class="eyebrow">The space</p><h2 class="display">4929 Wilshire Blvd, Suite 104.</h2><p class="lead">In the lobby of the building on the corner of Wilshire and Highland, in Hancock Park. A full competition mat, a lounge for parents and visitors, men's and women's changing rooms with showers, and a parking lot with validation.</p></div>
    <div class="gallery rv stagger">
      <figure><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/facility-1.webp" alt="Lounge" loading="lazy"></figure>
      <figure><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/facility-2.webp" alt="Main mat" loading="lazy"></figure>
      <figure><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/facility-5.webp" alt="Academy interior" loading="lazy"></figure>
      <figure><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/facility-6.webp" alt="Academy interior" loading="lazy"></figure>
      <figure><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/facility-7.webp" alt="Championship wall" loading="lazy"></figure>
      <figure><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/facility-8.webp" alt="Academy interior" loading="lazy"></figure>
      <figure><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/facility-3.webp" alt="Mat" loading="lazy"></figure>
      <figure><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/facility-4.webp" alt="Academy interior" loading="lazy"></figure>
    </div>
    <p class="rv" style="margin-top:22px"><a class="btn line" href="/visit/">Parking and visitor information</a></p>
  </div>
</section>

<!-- /wp:html -->
