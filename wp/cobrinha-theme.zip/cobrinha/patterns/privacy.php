<?php
/**
 * Title: Privacy policy
 * Slug: cobrinha/privacy
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="phero">
  <div class="wrap">
    <p class="crumbs"><a href="/">Home</a> / Privacy</p>
    <h1 class="display">Privacy policy.</h1>
  </div>
</section>
<section>
  <div class="wrap prose">
    <p class="muted small">This page carries over the current policy from cobrinhabjj.com and should be reviewed by the academy before launch.</p>
    <h2>What we collect</h2>
    <p>When you book a class, sign a waiver or contact us, we collect the details you give us: your name, phone number, email, and for children, their age and a parent's contact details. Our booking and membership system (Gymdesk) stores this on our behalf.</p>
    <h2>How we use it</h2>
    <p>To confirm your class, run your membership, and tell you about schedule changes, closures and academy events. We do not sell or rent your information to anyone.</p>
    <h2>Cookies and analytics</h2>
    <p>The site uses Google Analytics to understand how pages are used. You can block analytics cookies in your browser without affecting the site.</p>
    <h2>Your choices</h2>
    <p>Email <a class="link" href="mailto:info@cobrinhabjj.com">info@cobrinhabjj.com</a> to see, correct or delete the information we hold about you, or to stop receiving messages.</p>
  </div>
</section>

<!-- /wp:html -->
