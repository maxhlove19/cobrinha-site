<?php
/**
 * Title: Adult beginners
 * Slug: cobrinha/start
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="phero img">
  <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/class-adults.webp" alt="" aria-hidden="true">
  <div class="wrap">
    <p class="crumbs"><a href="/">Home</a> / Adult beginners</p>
    <p class="eyebrow">Adults · no experience needed</p>
    <h1 class="display">Start here.</h1>
    <p class="lead">Everything you'd want to know before your first class, written for the person who has never stepped on a mat.</p>
    <div class="hero-actions" style="margin-top:22px"><a class="btn red big" href="/free-class/">Book a free class</a></div>
  </div>
</section>

<section>
  <div class="wrap split">
    <div class="rv">
      <p class="eyebrow">The four-week Beginners course</p>
      <h2 class="display">Built for zero experience.</h2>
      <p class="lead">Three classes a week for four weeks, $149, and you can start any week. Every technique is taught from the ground up: how to fall safely, how to stand up, how to escape the positions you'll actually end up in, and the first chokes and joint locks. You drill with a partner at your level while a black or brown belt watches every rep.</p>
      <ul class="checks">
        <li>Mon &amp; Wed 8:00 pm, Thu 6:10 pm. Your free trial is any of those three slots. Start any week; miss one and pick it up on the next cycle.</li>
        <li>Self-defense first: what to do if someone grabs you, tackles you or pins you.</li>
        <li>No sparring until you want it. Then it's controlled, with people who know you're new.</li>
        <li>After four weeks you join Fundamentals 1 and start earning stripes.</li>
      </ul>
      <a class="btn red" href="/free-class/">Try the first class free</a>
    </div>
    <div class="media tall rv r"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-fundamentals.webp" alt="An instructor demonstrates a sweep to the fundamentals class" loading="lazy"></div>
    <!-- Vimeo 1008192790 (beginners course video) is restricted to the cobrinhabjj.com domain; swap back in once the site is on that domain. -->
  </div>
</section>

<section class="mat">
  <div class="wrap">
    <div class="sec-head rv">
      <p class="eyebrow">Why people stay</p>
      <h2 class="display">What you actually get.</h2>
    </div>
    <div class="grid-3 rv stagger">
      <div class="step"><h3>Real self-defense</h3><p>Jiu-Jitsu was built so a smaller person can control a bigger one. You learn to stay calm on the ground, get up, and get away. That confidence changes how you walk into a room.</p></div>
      <div class="step"><h3>Fitness that doesn't feel like a workout</h3><p>An hour on the mat is strength, cardio and mobility at once. People lose weight here without ever counting anything, because they show up three times a week for the problem-solving, not the exercise.</p></div>
      <div class="step"><h3>A room that knows your name</h3><p>You'll train with lawyers, nurses, actors, students and grandparents. The person who helps you with your first escape will be someone who was new six months ago.</p></div>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="sec-head rv">
      <p class="eyebrow">Your first class, minute by minute</p>
      <h2 class="display">Nothing surprising.</h2>
    </div>
    <div class="steps rv stagger">
      <div class="step"><h3>Before</h3><p>Book ahead so an instructor is ready for you, and <a class="link" href="https://cobrinha-jiu-jitsu-academy.gymdesk.com/signup" target="_blank" rel="noopener">sign the waiver online</a> first; it creates your profile. Arrive 15 minutes early, rent a gi ($20, refunded when you sign up), meet the coach. Wear athletic clothes; bring water and flip-flops for the walk to the mat.</p></div>
      <div class="step"><h3>During</h3><p>A short warm-up of movements you'll use every class, then two or three techniques shown slowly and drilled with a partner. The coach walks the mat and fixes details.</p></div>
      <div class="step"><h3>After</h3><p>Watch the advanced students roll if you like, ask anything, and go home. If you want to keep going, we'll talk options then, not on the mat.</p></div>
    </div>
  </div>
</section>

<section class="mat">
  <div class="wrap">
    <div class="sec-head rv">
      <p class="eyebrow">Questions</p>
      <h2 class="display">Ask us anything. Here are the usual ones.</h2>
    </div>
    <div class="faq rv">
      <details><summary>How fit do I need to be?</summary><div class="ans">You don't. The beginners course is paced for the room and you rest when you need to. Most people are surprised how much of the first month is learning to relax.</div></details>
      <details><summary>I'm over 40. Is that a problem?</summary><div class="ans">No. A third of our adult students started after 40. Jiu-Jitsu rewards patience and technique over speed, which is why older beginners often progress faster than they expect.</div></details>
      <details><summary>Will I be paired with someone much bigger?</summary><div class="ans">Coaches pair by size and experience, especially in the beginners course. You'll drill with someone you can learn from safely.</div></details>
      <details><summary>Do I need to buy a gi?</summary><div class="ans">Not for the trial; rental is $20 and refunded when you sign up. If you join, you'll train in an academy gi (white or blue) with a rash guard underneath; we'll help you get sized.</div></details>
      <details><summary>What if I have an old injury?</summary><div class="ans">Tell the coach before class. Almost everything can be adapted, and the beginners course avoids the positions that stress knees and shoulders until you're ready for them.</div></details>
      <details><summary>How often should I come?</summary><div class="ans">Two or three times a week is the sweet spot for beginners. Once a week works; you'll just move a little slower.</div></details>
      <details><summary>How long until I get a blue belt?</summary><div class="ans">Typically one and a half to two years of consistent training. Stripes come along the way, roughly every few months, so you always know where you stand.</div></details>
    </div>
  </div>
</section>

<!-- /wp:html -->
