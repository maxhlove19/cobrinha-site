<?php
/**
 * Title: Page not found
 * Slug: cobrinha/404
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="phero">
  <div class="wrap">
    <p class="eyebrow">404</p>
    <h1 class="display">That page tapped out.</h1>
    <p class="lead">The site was rebuilt and some old links moved. Try one of these, or call <a class="link" href="tel:+13239319953">(323) 931-9953</a>.</p>
    <div class="hero-actions" style="margin-top:22px"><a class="btn red big" href="/free-class/">Book a free class</a><a class="btn ghost big" href="/schedule/">Schedule</a><a class="btn ghost big" href="/kids/">Kids</a><a class="btn ghost big" href="/pricing/">Membership</a></div>
  </div>
</section>

<!-- /wp:html -->
