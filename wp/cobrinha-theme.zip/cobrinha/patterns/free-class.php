<?php
/**
 * Title: Book a kids' free trial class
 * Slug: cobrinha/free-class
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="phero">
  <div class="wrap">
    <p class="crumbs"><a href="/">Home</a> / <a href="/kids/">Kids &amp; teens</a> / Free trial</p>
    <p class="eyebrow">Takes 20 seconds</p>
    <h1 class="display">Book your child's free trial class.</h1>
    <p class="lead">For kids and teens, ages 3–16. Two steps: sign the waiver online (it creates their profile), then tell us their age and when. Trials are one-on-one with an instructor, so we book them ahead. We confirm by text or email, usually within the hour during class times. The class is free; gear rental is $15, refunded in full if they sign up.</p>
    <div class="hero-actions" style="margin-top:22px"><a class="btn red big" href="https://cobrinha-jiu-jitsu-academy.gymdesk.com/signup" target="_blank" rel="noopener">Step 1 · Sign the waiver (creates your profile)</a><a class="btn ghost big" href="#bookForm">Step 2 · Pick your time</a></div>
  </div>
</section>

<section>
  <div class="wrap grid-2">
    <form class="form rv l" id="bookForm" method="post" action="https://formsubmit.co/info@cobrinhabjj.com" novalidate>
      <input type="hidden" name="_subject" value="Kids' free trial request — cobrinhabjj.com">
      <input type="hidden" name="_next" value="<?php echo esc_url( home_url( '/thanks/' ) ); ?>">
      <input type="hidden" name="_captcha" value="false">
      <input type="text" name="_honey" style="display:none" tabindex="-1" autocomplete="off">
      <input type="hidden" name="program" value="Kids (ages 3–16)">
      <div class="row">
        <label>Parent's name <input type="text" name="name" autocomplete="name" required></label>
        <label>Phone <input type="tel" name="phone" autocomplete="tel" inputmode="tel" required></label>
      </div>
      <label>Email <input type="email" name="email" autocomplete="email" required></label>
      <label>Child's age <input type="text" name="child_age" inputmode="numeric" placeholder="e.g. 6" required></label>
      <label>Pick a free-trial time <select name="when">
        <optgroup label="Kids 3–4 (30 min)"><option>Tuesday 3:30 pm</option><option>Thursday 3:30 pm</option></optgroup>
        <optgroup label="Kids 5–6 (30 min)"><option>Monday 3:30 pm</option><option>Wednesday 3:30 pm</option></optgroup>
        <optgroup label="Kids 7–12"><option>Monday 5:00 pm</option><option>Tuesday 5:00 pm</option><option>Wednesday 5:00 pm</option><option>Thursday 5:00 pm</option></optgroup>
        <optgroup label="Teens 13–16"><option>Tuesday 5:00 pm</option><option>Thursday 5:00 pm</option></optgroup>
        <option>Not sure, call me</option>
      </select></label>
      <label>Anything we should know? <textarea name="notes" rows="3" placeholder="Injuries, experience, questions"></textarea></label>
      <button class="btn red big" type="submit">Request the free trial</button>
      <p class="fine">We'll text or email to confirm. No spam, no sales calls. Prefer to talk? Call or <a class="link" href="sms:+13239319953">text</a> <a class="link" href="tel:+13239319953">(323) 931-9953</a>.</p>
    </form>
    <div class="rv r">
      <p class="eyebrow">What happens next</p>
      <h2 class="display">Your first visit.</h2>
      <ol class="prose" style="padding-left:20px">
        <li><b>We confirm a time.</b> Their age group's slot below, one-on-one with an instructor, which is why we ask you to book rather than walk in.</li>
        <li><b>Arrive 15 minutes early.</b> Sign the waiver at the desk (or <a class="link" href="https://cobrinha-jiu-jitsu-academy.gymdesk.com/signup" target="_blank" rel="noopener">do it online now</a>), meet the coach, rent a gi ($15, refunded when they sign up).</li>
        <li><b>Train.</b> A warm-up, a few techniques with the instructor, and a look at what their class does.</li>
        <li><b>Decide later.</b> Nobody sells you at the desk. If they liked it, we'll show you the options and the class times that fit your week.</li>
      </ol>
      <div class="strip" style="margin-top:22px">
        <div class="srow"><b>Kids 3–4 · 30 min</b><span>Tue &amp; Thu 3:30 pm</span></div>
        <div class="srow"><b>Kids 5–6 · 30 min</b><span>Mon &amp; Wed 3:30 pm</span></div>
        <div class="srow"><b>Kids 7–12</b><span>Mon–Thu 5:00 pm</span></div>
        <div class="srow"><b>Teens 13–16</b><span>Tue &amp; Thu 5:00 pm</span></div>
      </div>
      <p class="eyebrow" style="margin-top:22px">Adults</p>
      <p><b>There is no adult trial class.</b> Adults start with the four-week Beginners course (Mon &amp; Wed 8:00 pm, Thu 6:10 pm, start any week) or sign up directly. <a class="link" href="/start/">Adult beginners: start here</a>.</p>
      <p class="small muted">Prefer to book straight into the schedule? <a class="link" href="https://cobrinha-jiu-jitsu-academy.gymdesk.com/book" target="_blank" rel="noopener">Book in Gymdesk</a>.</p>
      <p class="small muted">Parking is free with validation before 8:30 am, after 6 pm and on weekends. <a class="link" href="/visit/">Visitor info</a>.</p>
    </div>
  </div>
</section>

<!-- /wp:html -->
