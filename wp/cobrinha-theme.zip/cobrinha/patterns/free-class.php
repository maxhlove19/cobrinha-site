<?php
/**
 * Title: Book a free class
 * Slug: cobrinha/free-class
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="phero">
  <div class="wrap">
    <p class="crumbs"><a href="/">Home</a> / Free class</p>
    <p class="eyebrow">Takes 20 seconds</p>
    <h1 class="display">Book your free class.</h1>
    <p class="lead">Two steps: sign the waiver online (it creates your profile), then tell us who's coming and when. Trials are booked ahead so an instructor is ready for you; kids' trials are one-on-one. We confirm by text or email, usually within the hour during class times. The class is free; gear rental is $20 for adults and $15 for kids, refunded in full if you sign up.</p>
    <div class="hero-actions" style="margin-top:22px"><a class="btn red big" href="https://cobrinha-jiu-jitsu-academy.gymdesk.com/signup" target="_blank" rel="noopener">Step 1 · Sign the waiver (creates your profile)</a><a class="btn ghost big" href="#bookForm">Step 2 · Pick your time</a></div>
  </div>
</section>

<section>
  <div class="wrap grid-2">
    <form class="form rv l" id="bookForm" method="post" action="https://formsubmit.co/info@cobrinhabjj.com" novalidate>
      <input type="hidden" name="_subject" value="Free class request — cobrinhabjj.com">
      <input type="hidden" name="_next" value="{{thanks}}">
      <input type="hidden" name="_captcha" value="false">
      <input type="text" name="_honey" style="display:none" tabindex="-1" autocomplete="off">
      <p class="label">Who is the class for?</p>
      <div class="pick">
        <label><input type="radio" name="program" value="Adult beginner" checked><b>Me — adult beginner</b><span>Never trained, or a long time ago</span></label>
        <label><input type="radio" name="program" value="Kids (ages 3–16)"><b>My child</b><span>Ages 3–16, grouped by age</span></label>
        <label><input type="radio" name="program" value="Women's program"><b>Women's class</b><span>Women only, black belt coach</span></label>
      </div>
      <div class="row">
        <label>Your name <input type="text" name="name" autocomplete="name" required></label>
        <label>Phone <input type="tel" name="phone" autocomplete="tel" inputmode="tel" required></label>
      </div>
      <label>Email <input type="email" name="email" autocomplete="email" required></label>
      <label>Child's age (if booking for a child) <input type="text" name="child_age" inputmode="numeric" placeholder="e.g. 6"></label>
      <label>Pick a free-trial time <select name="when">
        <optgroup label="Adults"><option>Monday 8:00 pm</option><option>Wednesday 8:00 pm</option><option>Thursday 6:10 pm</option></optgroup>
        <optgroup label="Kids 3–4 (30 min)"><option>Tuesday 3:30 pm</option><option>Thursday 3:30 pm</option></optgroup>
        <optgroup label="Kids 5–6 (30 min)"><option>Monday 3:30 pm</option><option>Wednesday 3:30 pm</option></optgroup>
        <optgroup label="Kids 7–12"><option>Monday 5:00 pm</option><option>Tuesday 5:00 pm</option><option>Wednesday 5:00 pm</option><option>Thursday 5:00 pm</option></optgroup>
        <optgroup label="Teens 13–16"><option>Tuesday 5:00 pm</option><option>Thursday 5:00 pm</option></optgroup>
        <optgroup label="Women's"><option>Wednesday 6:10 pm (women's trial, best slot)</option><option>Tuesday 6:10 pm (women's trial)</option><option>Thursday 6:10 pm (women's trial)</option></optgroup>
        <option>Not sure, call me</option>
      </select></label>
      <label>Anything we should know? <textarea name="notes" rows="3" placeholder="Injuries, experience, questions"></textarea></label>
      <button class="btn red big" type="submit">Request my free class</button>
      <p class="fine">We'll text or email to confirm. No spam, no sales calls. Prefer to talk? Call or <a class="link" href="sms:+13239319953">text</a> <a class="link" href="tel:+13239319953">(323) 931-9953</a>.</p>
    </form>
    <div class="rv r">
      <p class="eyebrow">What happens next</p>
      <h2 class="display">Your first visit.</h2>
      <ol class="prose" style="padding-left:20px">
        <li><b>We confirm a time.</b> Adults: any Monday or Wednesday at 8:00 pm, or Thursday at 6:10 pm. Kids: their age group's slot below, one-on-one with an instructor, which is why we ask you to book rather than walk in.</li>
        <li><b>Arrive 15 minutes early.</b> Sign the waiver at the desk (or <a class="link" href="https://cobrinha-jiu-jitsu-academy.gymdesk.com/signup" target="_blank" rel="noopener">do it online now</a>), meet the coach, rent a gi ($20 adults, $15 kids, refunded when you sign up).</li>
        <li><b>Train.</b> Warm-up, two or three techniques with a partner, and a look at what the room does. You decide if you spar.</li>
        <li><b>Decide later.</b> Nobody sells you at the desk. If you liked it, we'll show you the options and the schedule that fits your week.</li>
      </ol>
      <div class="strip" style="margin-top:22px">
        <div class="srow"><b>Adults</b><span>Mon &amp; Wed 8:00 pm · Thu 6:10 pm</span></div>
        <div class="srow"><b>Women's</b><span>Wed 6:10 pm · also Tue &amp; Thu 6:10 pm</span></div>
        <div class="srow"><b>Kids 3–4 · 30 min</b><span>Tue &amp; Thu 3:30 pm</span></div>
        <div class="srow"><b>Kids 5–6 · 30 min</b><span>Mon &amp; Wed 3:30 pm</span></div>
        <div class="srow"><b>Kids 7–12</b><span>Mon–Thu 5:00 pm</span></div>
        <div class="srow"><b>Teens 13–16</b><span>Tue &amp; Thu 5:00 pm</span></div>
      </div>
      <p class="small muted">Prefer to book straight into the schedule? <a class="link" href="https://cobrinha-jiu-jitsu-academy.gymdesk.com/book" target="_blank" rel="noopener">Book in Gymdesk</a>.</p>
      <p class="small muted">Parking is free with validation before 8:30 am, after 6 pm and on weekends. <a class="link" href="/visit/">Visitor info</a>.</p>
    </div>
  </div>
</section>

<!-- /wp:html -->
