<?php
/**
 * Title: Class schedule
 * Slug: cobrinha/schedule
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="phero">
  <div class="wrap">
    <p class="crumbs"><a href="/">Home</a> / Schedule</p>
    <p class="eyebrow">Every day of the week</p>
    <h1 class="display">Schedule.</h1>
    <p class="lead">Filter by program. Free-trial slots are marked: adults Mon &amp; Wed 8 pm or Thu 6:10 pm; women Wed 6:10 pm (or Tue/Thu 6:10 pm); kids 3–6 at 3:30 pm (30 min), 7–12 Mon–Thu 5 pm, teens Tue &amp; Thu 5 pm. New students <a class="link" href="/free-class/">book ahead</a> so an instructor is ready, and <a class="link" href="https://cobrinha-jiu-jitsu-academy.gymdesk.com/signup" target="_blank" rel="noopener">sign the waiver online</a> first.</p>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="days rv" id="days"><button class="day" data-d="Mon" aria-pressed="true">Mon</button><button class="day" data-d="Tue" aria-pressed="false">Tue</button><button class="day" data-d="Wed" aria-pressed="false">Wed</button><button class="day" data-d="Thu" aria-pressed="false">Thu</button><button class="day" data-d="Fri" aria-pressed="false">Fri</button><button class="day" data-d="Sat" aria-pressed="false">Sat</button><button class="day" data-d="Sun" aria-pressed="false">Sun</button></div>
    <div class="wgrid-wrap rv"><div class="wgrid" id="wgrid"></div></div>
    <div class="legend rv" id="legend"></div>
    <p class="small muted rv" style="margin-top:16px">Sunday is members' open mat only, 10 am. Private lessons are booked directly with the instructor. This grid is read from Gymdesk, so it changes the moment the academy updates its schedule there; holiday hours are announced a week ahead.</p>
    <div class="rv" style="margin-top:22px;display:flex;gap:12px;flex-wrap:wrap">
      <a class="btn red" href="/free-class/">Book a free class</a>
      <a class="btn line" href="https://cobrinha-jiu-jitsu-academy.gymdesk.com/schedule" target="_blank" rel="noopener">Members: book in Gymdesk</a>
    </div>
  </div>
</section>

<!-- /wp:html -->
