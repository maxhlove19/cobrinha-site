<?php
/**
 * Title: Class schedule
 * Slug: cobrinha/schedule
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="phero">
  <div class="wrap">
    <p class="crumbs"><a href="/">Home</a> / Schedule</p>
    <p class="eyebrow">Every day of the week</p>
    <h1 class="display">Schedule.</h1>
    <p class="lead">Days across, times down, straight from Gymdesk. New adults start with the four-week <a class="link" href="/start/">Beginners course</a> (Mon &amp; Wed 8:00 pm, Thu 6:10 pm) or <a class="link" href="https://cobrinha-jiu-jitsu-academy.gymdesk.com/signup" target="_blank" rel="noopener">sign up directly</a>; kids and teens <a class="link" href="/free-class/">book a free trial class</a>. Everyone should <a class="link" href="https://cobrinha-jiu-jitsu-academy.gymdesk.com/signup" target="_blank" rel="noopener">sign the waiver online</a> first.</p>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="days rv" id="days"><button class="day" data-d="Mon" aria-pressed="true">Mon</button><button class="day" data-d="Tue" aria-pressed="false">Tue</button><button class="day" data-d="Wed" aria-pressed="false">Wed</button><button class="day" data-d="Thu" aria-pressed="false">Thu</button><button class="day" data-d="Fri" aria-pressed="false">Fri</button><button class="day" data-d="Sat" aria-pressed="false">Sat</button><button class="day" data-d="Sun" aria-pressed="false">Sun</button></div>
    <div class="wgrid-wrap rv"><div class="wgrid" id="wgrid"></div></div>
    <div class="legend rv" id="legend"></div>
    <p class="small muted rv" style="margin-top:16px">Sunday's 10 am All Levels class is for members only. Private lessons are booked directly with the instructor. This grid is read from Gymdesk, so it changes the moment the academy updates its schedule there; holiday hours are announced a week ahead.</p>
    <div class="rv" style="margin-top:22px;display:flex;gap:12px;flex-wrap:wrap">
      <a class="btn red" href="/start/">Start training</a>
      <a class="btn line" href="https://cobrinha-jiu-jitsu-academy.gymdesk.com/schedule" target="_blank" rel="noopener">Members: book in Gymdesk</a>
    </div>
  </div>
</section>

<!-- /wp:html -->
