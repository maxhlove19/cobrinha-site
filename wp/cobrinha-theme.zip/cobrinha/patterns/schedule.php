<?php
/**
 * Title: Class schedule
 * Slug: cobrinha/schedule
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="phero">
  <div class="wrap">
    <p class="crumbs"><a href="/">Home</a> / Schedule</p>
    <p class="eyebrow">Every day of the week</p>
    <h1 class="display">Schedule.</h1>
    <p class="lead">Filter by program. Free-trial slots are marked: adults Mon &amp; Wed 8 pm or Thu 6:10 pm; women Wed 6:10 pm (or Tue/Thu 6:10 pm); kids 3–6 at 3:30 pm (30 min), 7–12 Mon–Thu 5 pm, teens Tue &amp; Thu 5 pm. New students <a class="link" href="/free-class/">book ahead</a> so an instructor is ready, and <a class="link" href="https://cobrinha-jiu-jitsu-academy.gymdesk.com/signup" target="_blank" rel="noopener">sign the waiver online</a> first.</p>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="days rv" id="days"><button class="day" data-d="all" aria-pressed="true">All days</button><button class="day" data-d="Mon" aria-pressed="false">Mon</button><button class="day" data-d="Tue" aria-pressed="false">Tue</button><button class="day" data-d="Wed" aria-pressed="false">Wed</button><button class="day" data-d="Thu" aria-pressed="false">Thu</button><button class="day" data-d="Fri" aria-pressed="false">Fri</button><button class="day" data-d="Sat" aria-pressed="false">Sat</button><button class="day" data-d="Sun" aria-pressed="false">Sun</button></div>
    <div class="tabs rv" role="tablist">
      <button class="tab" role="tab" data-filter="all" aria-selected="true">All</button>
      <button class="tab" role="tab" data-filter="beg" aria-selected="false">Beginners &amp; Fundamentals</button>
      <button class="tab" role="tab" data-filter="adv" aria-selected="false">Advanced</button>
      <button class="tab" role="tab" data-filter="nogi" aria-selected="false">No-Gi</button>
      <button class="tab" role="tab" data-filter="women" aria-selected="false">Women's</button>
      <button class="tab" role="tab" data-filter="kids" aria-selected="false">Kids &amp; teens</button>
    </div>
    <div class="sched-wrap rv">
      <table class="sched">
        <thead><tr><th>Day</th><th>Time</th><th>Class</th></tr></thead>
        <tbody>
          <tr data-k="beg"><td class="d">Mon</td><td class="t">6:30 – 7:30 am</td><td>Fundamentals 2 <span class="tag">3 stripes +</span></td></tr>
          <tr data-k="adv"><td class="d">Mon</td><td class="t">12:00 – 1:30 pm</td><td>Advanced BJJ <span class="tag">Blue belt +</span></td></tr>
          <tr data-k="kids"><td class="d">Mon</td><td class="t">3:30 – 4:00 pm</td><td>Kids Free Trial <span class="tag">Ages 5–6</span> <span class="tag free">Free trial</span></td></tr>
          <tr data-k="kids"><td class="d">Mon</td><td class="t">4:10 – 4:45 pm</td><td>Little Eagles <span class="tag">Ages 5–6</span></td></tr>
          <tr data-k="kids"><td class="d">Mon</td><td class="t">5:00 – 6:00 pm</td><td>Eagle Warriors <span class="tag">Ages 7–12</span> <span class="tag free">Free trial</span></td></tr>
          <tr data-k="beg"><td class="d">Mon</td><td class="t">6:10 – 7:10 pm</td><td>Fundamentals 2 <span class="tag">3 stripes +</span></td></tr>
          <tr data-k="adv"><td class="d">Mon</td><td class="t">7:20 – 8:50 pm</td><td>Advanced <span class="tag">Blue belt +</span></td></tr>
          <tr data-k="beg"><td class="d">Mon</td><td class="t">8:00 – 9:00 pm</td><td>Fundamentals 1 · Beginners course <span class="tag">All levels</span> <span class="tag free">Free trial</span></td></tr>

          <tr data-k="beg"><td class="d">Tue</td><td class="t">6:30 – 7:30 am</td><td>Fundamentals 1 <span class="tag">All levels</span></td></tr>
          <tr data-k="beg adv"><td class="d">Tue</td><td class="t">6:30 – 7:45 am</td><td>All Levels <span class="tag">3 stripes +</span></td></tr>
          <tr data-k="women"><td class="d">Tue</td><td class="t">8:00 – 9:00 am</td><td>Women's Class <span class="tag">Women only</span></td></tr>
          <tr data-k="nogi adv"><td class="d">Tue</td><td class="t">12:00 – 1:30 pm</td><td>No-Gi Advanced <span class="tag">Blue belt +</span></td></tr>
          <tr data-k="kids"><td class="d">Tue</td><td class="t">3:30 – 4:00 pm</td><td>Kids Free Trial <span class="tag">Ages 3–4</span> <span class="tag free">Free trial</span></td></tr>
          <tr data-k="kids"><td class="d">Tue</td><td class="t">4:10 – 4:45 pm</td><td>Baby Eagles <span class="tag">Ages 3–4</span></td></tr>
          <tr data-k="kids"><td class="d">Tue</td><td class="t">5:00 – 6:00 pm</td><td>Eagle Warriors <span class="tag">Ages 7–12</span> &nbsp; Eagle Teens <span class="tag">Ages 13–16</span> <span class="tag free">Free trial</span></td></tr>
          <tr data-k="beg"><td class="d">Tue</td><td class="t">6:10 – 7:10 pm</td><td>Fundamentals 1 <span class="tag">White belt +</span></td></tr>
          <tr data-k="nogi beg"><td class="d">Tue</td><td class="t">6:10 – 7:10 pm</td><td>No-Gi Fundamentals</td></tr>
          <tr data-k="women"><td class="d">Tue</td><td class="t">6:10 – 7:10 pm</td><td>Women's Free Trial <span class="tag free">Free trial</span></td></tr>
          <tr data-k="nogi"><td class="d">Tue</td><td class="t">7:20 – 8:40 pm</td><td>No-Gi <span class="tag">3 stripes +</span></td></tr>

          <tr data-k="beg"><td class="d">Wed</td><td class="t">6:30 – 7:30 am</td><td>Fundamentals 2 <span class="tag">3 stripes +</span></td></tr>
          <tr data-k="adv"><td class="d">Wed</td><td class="t">12:00 – 1:30 pm</td><td>Advanced BJJ <span class="tag">Blue belt +</span></td></tr>
          <tr data-k="kids"><td class="d">Wed</td><td class="t">3:30 – 4:00 pm</td><td>Kids Free Trial <span class="tag">Ages 5–6</span> <span class="tag free">Free trial</span></td></tr>
          <tr data-k="kids"><td class="d">Wed</td><td class="t">4:10 – 4:45 pm</td><td>Little Eagles <span class="tag">Ages 5–6</span></td></tr>
          <tr data-k="kids"><td class="d">Wed</td><td class="t">5:00 – 6:00 pm</td><td>Eagle Warriors <span class="tag">Ages 7–12</span> <span class="tag free">Free trial</span></td></tr>
          <tr data-k="beg"><td class="d">Wed</td><td class="t">6:10 – 7:10 pm</td><td>Fundamentals 2 <span class="tag">3 stripes +</span></td></tr>
          <tr data-k="women"><td class="d">Wed</td><td class="t">6:10 – 7:10 pm</td><td>Women's Free Trial <span class="tag free">Free trial · best slot</span></td></tr>
          <tr data-k="adv"><td class="d">Wed</td><td class="t">7:20 – 8:50 pm</td><td>Advanced <span class="tag">Blue belt +</span></td></tr>
          <tr data-k="beg"><td class="d">Wed</td><td class="t">8:00 – 9:00 pm</td><td>Fundamentals 1 · Beginners course <span class="tag">All levels</span> <span class="tag free">Free trial</span></td></tr>

          <tr data-k="beg adv"><td class="d">Thu</td><td class="t">6:30 – 7:45 am</td><td>All Levels <span class="tag">3 stripes +</span></td></tr>
          <tr data-k="nogi adv"><td class="d">Thu</td><td class="t">12:00 – 1:30 pm</td><td>No-Gi Advanced <span class="tag">Blue belt +</span></td></tr>
          <tr data-k="kids"><td class="d">Thu</td><td class="t">3:30 – 4:00 pm</td><td>Kids Free Trial <span class="tag">Ages 3–4</span> <span class="tag free">Free trial</span></td></tr>
          <tr data-k="kids"><td class="d">Thu</td><td class="t">4:10 – 4:45 pm</td><td>Baby Eagles <span class="tag">Ages 3–4</span></td></tr>
          <tr data-k="kids"><td class="d">Thu</td><td class="t">5:00 – 6:00 pm</td><td>Eagle Warriors <span class="tag">Ages 7–12</span> &nbsp; Eagle Teens <span class="tag">Ages 13–16</span> <span class="tag free">Free trial</span></td></tr>
          <tr data-k="beg"><td class="d">Thu</td><td class="t">6:10 – 7:10 pm</td><td>Fundamentals 1 · Beginners course <span class="tag">White belt +</span> <span class="tag free">Free trial</span></td></tr>
          <tr data-k="nogi beg"><td class="d">Thu</td><td class="t">6:10 – 7:10 pm</td><td>No-Gi Fundamentals</td></tr>
          <tr data-k="women"><td class="d">Thu</td><td class="t">6:10 – 7:10 pm</td><td>Women's Free Trial <span class="tag free">Free trial</span></td></tr>
          <tr data-k="nogi"><td class="d">Thu</td><td class="t">7:20 – 8:40 pm</td><td>No-Gi <span class="tag">3 stripes +</span></td></tr>

          <tr data-k="beg adv"><td class="d">Fri</td><td class="t">6:30 – 7:30 am</td><td>Conditioning, then rolling <span class="tag">All levels</span></td></tr>
          <tr data-k="adv"><td class="d">Fri</td><td class="t">12:00 – 1:30 pm</td><td>Advanced BJJ <span class="tag">Blue belt +</span></td></tr>
          <tr data-k="kids"><td class="d">Fri</td><td class="t">4:10 – 4:45 pm</td><td>Little Eagles <span class="tag">Ages 5–6</span></td></tr>
          <tr data-k="kids nogi"><td class="d">Fri</td><td class="t">5:00 – 6:00 pm</td><td>Eagle Warriors No-Gi <span class="tag">All levels</span></td></tr>
          <tr data-k="beg"><td class="d">Fri</td><td class="t">6:20 – 7:50 pm</td><td>Fundamentals 2 <span class="tag">4 stripes +</span></td></tr>

          <tr data-k="kids"><td class="d">Sat</td><td class="t">9:00 – 10:00 am</td><td>Eagle Warriors <span class="tag">All levels</span></td></tr>
          <tr data-k="beg adv"><td class="d">Sat</td><td class="t">10:00 – 11:00 am</td><td>Capofit Workout <span class="tag">Conditioning</span></td></tr>
          <tr data-k="beg"><td class="d">Sat</td><td class="t">11:15 am – 12:15 pm</td><td>Fundamentals 3 <span class="tag">4 stripes +</span></td></tr>
          <tr data-k="women"><td class="d">Sat</td><td class="t">11:15 am – 12:15 pm</td><td>Women's Class <span class="tag">Women only</span></td></tr>
          <tr data-k="adv beg nogi"><td class="d">Sun</td><td class="t">10:00 am</td><td>Open Mat · all levels <span class="tag">Members only</span></td></tr>
        </tbody>
      </table>
    </div>
    <p class="small muted rv" style="margin-top:16px">Sunday is members' open mat only, 10 am. Private lessons are booked directly with the instructor. Schedule updates are posted in Gymdesk and on Instagram; holiday hours are announced a week ahead.</p>
    <div class="rv" style="margin-top:22px;display:flex;gap:12px;flex-wrap:wrap">
      <a class="btn red" href="/free-class/">Book a free class</a>
      <a class="btn line" href="https://cobrinha-jiu-jitsu-academy.gymdesk.com/schedule" target="_blank" rel="noopener">Members: book in Gymdesk</a>
    </div>
  </div>
</section>

<!-- /wp:html -->
