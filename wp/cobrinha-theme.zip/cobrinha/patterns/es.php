<?php
/**
 * Title: Jiu-Jitsu Brasileño en Los Ángeles
 * Slug: cobrinha/es
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<header class="hero">
  <img class="hero-img" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/hero-mat.webp" alt="Cobrinha sentado al frente de un tatami lleno de alumnos en la academia de Los Ángeles" fetchpriority="high">
  <div class="hero-in">
    <div class="hero-copy">
    <p class="eyebrow light">Jiu-Jitsu Brasileño · Wilshire y Highland, Los Ángeles</p>
    <h1 class="display">Entrena con una leyenda.<br><span class="thin">Empieza desde cero.</span></h1>
    <p class="hero-badge">El único campeón del Super Grand Slam en la historia</p>
    <p class="lead">Dirigido por Rubens "Cobrinha" Charles, cinco veces campeón mundial. Dieciséis años en Wilshire. Tu primera clase es gratis.</p>
    <div class="hero-actions">
      <a class="btn red big" href="/free-class/">Reservar clase gratis</a>
      <a class="btn ghost big" href="/schedule/">Ver horarios</a>
    </div>
    <div class="chips">
      <span class="chip"><b>16</b> años en Wilshire</span>
      <span class="chip"><b><span class="star">★</span> 4.9</b> en Google</span>
      <span class="chip"><b>5×</b> campeón mundial</span>
      <span class="chip"><b>Único</b> campeón del Super Grand Slam</span>
    </div>
    </div>
  </div>
</header>

<section class="dark proof">
  <div class="wrap proof-in">
    <div class="stat"><b><span data-count="16">0</span></b><span>Años en Wilshire</span></div>
    <div class="stat"><b><span data-count="5">0</span><i>×</i></b><span>Campeón Mundial IBJJF</span></div>
    <div class="stat"><b><span data-count="3">0</span><i>×</i></b><span>Campeón ADCC</span></div>
    <div class="stat"><b><span data-count="4.9">0</span></b><span>Calificación en Google, 200 reseñas</span></div>
    <div class="stat"><b>Único</b><span>Campeón del Super Grand Slam en la historia</span></div>
  </div>
</section>

<section class="mat">
  <div class="wrap">
    <div class="sec-head rv">
      <p class="eyebrow">¿Nunca has entrenado? Empieza aquí.</p>
      <h2 class="display">Tu primer mes, paso a paso.</h2>
      <p class="lead">La mayoría de las personas que entran nunca han practicado un arte marcial. El camino es simple y nadie entra a la clase avanzada.</p>
    </div>
    <div class="steps rv stagger">
      <div class="step"><h3>Reserva una clase gratis</h3><p>Elige una hora y avísanos que vienes, para que un instructor te espere. Firma la exención en línea primero; crea tu perfil. Alquila un gi en recepción ($20, se devuelve al inscribirte).</p><p class="when">Lun y Mié 8 pm · Jue 6:10 pm</p></div>
      <div class="step"><h3>Curso de principiantes de cuatro semanas</h3><p>Tres clases por semana para personas sin experiencia: cómo caer, cómo levantarse, cómo escapar, las primeras finalizaciones. Enseñado por cinturones negros y marrones.</p><p class="when">Lun y Mié 8 pm · Jue 6:10 pm · empieza cualquier semana</p></div>
      <div class="step"><h3>Únete a Fundamentos</h3><p>Después del curso pasas a Fundamentos 1 con personas de tu nivel, y ganas tus grados hacia Fundamentos 2 y la sala avanzada.</p><p class="when">Todos los días, mañana y tarde</p></div>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="sec-head rv"><p class="eyebrow">Programas</p><h2 class="display">Una clase para donde estás.</h2></div>
    <div class="prog rv stagger">
      <a class="pcard" href="/start/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/beginners.webp" alt="" loading="lazy"><div class="pin"><small>Adultos · sin experiencia</small><b>Principiantes</b><span>Curso de cuatro semanas</span></div></a>
      <a class="pcard" href="/programs/#fundamentals"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-fundamentals.webp" alt="" loading="lazy"><div class="pin"><small>Adultos</small><b>Fundamentos</b><span>Niveles 1, 2 y 3</span></div></a>
      <a class="pcard" href="/programs/#nogi"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-nogi-1.webp" alt="" loading="lazy"><div class="pin"><small>Todos los niveles</small><b>No-Gi</b><span>Seis clases por semana</span></div></a>
      <a class="pcard" href="/womens/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-womens-1.webp" alt="" loading="lazy"><div class="pin"><small>Solo mujeres</small><b>Mujeres</b><span>Instructora cinturón negro</span></div></a>
      <a class="pcard" href="/kids/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/kids-run.webp" alt="" loading="lazy"><div class="pin"><small>3 a 12 años</small><b>Niños · Eagles</b><span>Cuatro grupos por edad</span></div></a>
      <a class="pcard" href="/kids/#teens"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-kids-coach.webp" alt="" loading="lazy"><div class="pin"><small>13 a 16 años</small><b>Adolescentes</b><span>Mar y Jue 5 pm</span></div></a>
      <a class="pcard" href="/programs/#advanced"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-nogi-win.webp" alt="" loading="lazy"><div class="pin"><small>Cinturón azul en adelante</small><b>Avanzado y competición</b><span>La sala de Cobrinha</span></div></a>
      <a class="pcard" href="/programs/#private"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/cobrinha.webp" alt="" loading="lazy"><div class="pin"><small>Uno a uno</small><b>Clases privadas</b><span>Instructores cinturón negro y marrón</span></div></a>
    </div>
  </div>
</section>

<section class="mat">
  <div class="wrap split">
    <div class="media wide rv l"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/kids-run.webp" alt="Seis niños con gi corriendo por el tatami, riendo" loading="lazy"></div>
    <div class="rv r">
      <p class="eyebrow">Niños y adolescentes · programa Eagles</p>
      <h2 class="display">Confianza que se ganan ellos mismos.</h2>
      <p class="lead">De 3 a 16 años, agrupados por edad y nivel. El Jiu-Jitsu es el arte marcial más seguro para empezar: sin golpes, sin patadas, y con una técnica que permite al niño más pequeño controlar al más grande.</p>
      <div class="strip">
        <div class="srow"><b>Baby Eagles · 3–4 años</b><span>Mar y Jue 4:10 pm · prueba 3:30 pm</span></div>
        <div class="srow"><b>Little Eagles · 5–6 años</b><span>Lun, Mié y Vie 4:10 pm · prueba 3:30 pm</span></div>
        <div class="srow"><b>Eagle Warriors · 7–12 años</b><span>Lun a Jue 5:00 pm · Sáb 9 am</span></div>
        <div class="srow"><b>Eagle Teens · 13–16 años</b><span>Mar y Jue 5:00 pm</span></div>
      </div>
      <p class="small muted">La clase de prueba es gratis y uno a uno con un instructor: reserva con anticipación. Alquiler de gi $15, se devuelve al inscribirse.</p>
      <a class="btn red" href="free-class.html?program=kids">Reservar prueba para niños</a>
    </div>
  </div>
</section>

<section class="dark">
  <div class="wrap split rev">
    <div class="media tall rv r"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/cobrinha.webp" alt="Rubens Cobrinha Charles con su gi de Alliance, brazos cruzados, sonriendo" loading="lazy"></div>
    <div class="rv l">
      <p class="eyebrow light">Instructor principal</p>
      <h2 class="display">Rubens "Cobrinha" Charles</h2>
      <p class="lead">El único cinturón negro de la historia en ganar ADCC, el Mundial, el Panamericano, el Europeo y el Brasileño en un mismo año. Enseña en este tatami cada semana, y enseña a principiantes.</p>
      <ul class="titles">
        <li><b>5×</b><span>Campeón Mundial IBJJF (2006–2009, 2017)</span></li>
        <li><b>4×</b><span>Campeón Mundial No-Gi IBJJF</span></li>
        <li><b>3×</b><span>Campeón Mundial ADCC (2013, 2015, 2017)</span></li>
        <li><b>HOF</b><span>Salón de la Fama IBJJF y ADCC</span></li>
      </ul>
      <a class="btn ghost" href="/instructors/" style="margin-top:14px">Conoce a los instructores</a>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="sec-head rv"><p class="eyebrow">Membresía</p><h2 class="display">Una membresía, toda la academia.</h2><p class="lead">Prueba una clase gratis primero. Las membresías se renuevan cada mes con 30 días de aviso e incluyen todos los programas y todos los instructores, seis días a la semana. En recepción te explican los planes después de tu primera clase. Descuento familiar a partir del segundo miembro.</p></div>
    <div class="plans rv up">
      <div class="plan"><p class="plan-name">Silver</p><p class="plan-count">8<span>clases al mes</span></p><p class="plan-per">Dos veces por semana, cualquier programa</p></div>
      <div class="plan hot"><p class="plan-name">Gold</p><p class="plan-count">12<span>clases al mes</span></p><p class="plan-per">Tres veces por semana</p></div>
      <div class="plan"><p class="plan-name">Platinum</p><p class="plan-count">Ilimitado<span>clases</span></p><p class="plan-per">Todos los días, gi y no-gi</p></div>
      <div class="plan"><p class="plan-name">Niños y adolescentes</p><p class="plan-count">3–16<span>años</span></p><p class="plan-per">Su grupo de edad · descuento familiar</p></div>
    </div>
    </div>
  </div>
</section>

<section class="mat">
  <div class="wrap">
    <div class="sec-head rv"><p class="eyebrow">Preguntas frecuentes</p><h2 class="display">Respuestas directas.</h2></div>
    <div class="faq rv">
      <details><summary>Nunca he practicado un arte marcial. ¿Me voy a perder?</summary><div class="ans">No. Los principiantes empiezan en un curso de cuatro semanas hecho para cero experiencia, y luego pasan a Fundamentos con personas de su mismo nivel. Nadie hace sparring en su primera clase a menos que lo pida.</div></details>
      <details><summary>¿Cuándo es la clase de prueba gratis?</summary><div class="ans">Adultos: cualquier lunes o miércoles a las 8:00 pm, o jueves a las 6:10 pm. Mujeres: miércoles 6:10 pm (también martes o jueves 6:10 pm). Niños de 3 a 6: 3:30 pm (30 minutos); de 7 a 12: lunes a jueves 5:00 pm; adolescentes: martes o jueves 5:00 pm. Reserva con anticipación y firma la exención en línea.</div></details>
      <details><summary>¿Qué me pongo?</summary><div class="ans">Ropa deportiva cómoda. Alquila un gi en recepción ($20 adultos, $15 niños; se devuelve al inscribirte). Todos entrenan con un gi azul o blanco de Alliance o Cobrinha: somos un solo equipo.</div></details>
      <details><summary>¿Cuánto cuesta?</summary><div class="ans">Las membresías se renuevan cada mes, con 30 días de aviso para cancelar, desde 8 clases al mes hasta ilimitado, con descuento familiar a partir del segundo miembro. Prueba una clase gratis y en recepción te explican las opciones.</div></details>
      <details><summary>¿Dónde estaciono?</summary><div class="ans">En el estacionamiento del edificio con validación: gratis antes de las 8:30 am, después de las 6 pm y los fines de semana; $5 por dos horas al mediodía. Estacionamiento gratis en la calle Highland.</div></details>
      <details><summary>¿Hablan español?</summary><div class="ans">Sí. Varios instructores y el personal de recepción hablan español y portugués. Llama al <a class="link" href="tel:+13239319953">(323) 931-9953</a>.</div></details>
    </div>
    <p class="rv" style="margin-top:22px"><a class="btn line" href="/">Read this page in English</a></p>
  </div>
</section>

<!-- /wp:html -->
