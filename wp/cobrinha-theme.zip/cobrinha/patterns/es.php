<?php
/**
 * Title: Jiu-Jitsu Brasileño en Los Ángeles
 * Slug: cobrinha/es
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<header class="hero">
  <img class="hero-img" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/hero-mat.webp" alt="Cobrinha sentado al frente de un tatami lleno de alumnos en la academia de Los Ángeles" fetchpriority="high" width="1800" height="1013">
  <div class="hero-in">
    <div class="hero-copy">
    <p class="eyebrow light">Jiu-Jitsu Brasileño · Wilshire y Highland, Los Ángeles</p>
    <h1 class="display">Entrena con una leyenda.<br><span class="thin">Empieza desde cero.</span></h1>
    <p class="hero-badge">El único campeón del Super Grand Slam en la historia</p>
    <p class="lead">Dirigido por Rubens "Cobrinha" Charles, cinco veces campeón mundial. En Wilshire desde hace <span data-years>16</span> años. Empieza con el curso de principiantes de cuatro semanas o inscríbete directamente.</p>
    <div class="hero-actions">
      <a class="btn red big" href="/start/">Empieza a entrenar</a>
      <a class="btn ghost big" href="/schedule/">Ver horarios</a>
    </div>
    <div class="chips">
      <span class="chip"><b data-years>16</b> años en Wilshire</span>
      <span class="chip"><b><span class="star">★</span> 4.9</b> en Google</span>
      <span class="chip"><b>5×</b> campeón mundial</span>
      <span class="chip"><b>Único</b> campeón del Super Grand Slam</span>
    </div>
    </div>
  </div>
</header>

<section class="dark proof">
  <div class="wrap proof-in">
    <div class="stat"><b><span data-years>16</span></b><span>Años en Wilshire</span></div>
    <div class="stat"><b><span data-count="5">0</span><i>×</i></b><span>Campeón Mundial IBJJF</span></div>
    <div class="stat"><b><span data-count="3">0</span><i>×</i></b><span>Campeón ADCC</span></div>
    <div class="stat"><b><span data-count="4.9">0</span></b><span>Calificación en Google, 200 reseñas</span></div>
    <div class="stat"><b>Único</b><span>Campeón del Super Grand Slam en la historia</span></div>
  </div>
</section>


<section>
  <div class="wrap">
    <div class="sec-head rv"><p class="eyebrow">Programas</p><h2 class="display">Una clase para donde estás.</h2></div>
    <div class="prog rv stagger">
      <a class="pcard" href="/start/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/beginners.webp" alt="" loading="lazy" width="846" height="564"><div class="pin"><small>Adultos · sin experiencia</small><b>Principiantes</b><span>Curso de cuatro semanas</span></div></a>
      <a class="pcard" href="/programs/#fundamentals"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-fundamentals.webp" alt="" loading="lazy" width="720" height="1280"><div class="pin"><small>Adultos</small><b>Fundamentos</b><span>Niveles 1, 2 y 3</span></div></a>
      <a class="pcard" href="/programs/#nogi"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-nogi-1.webp" alt="" loading="lazy" width="899" height="992"><div class="pin"><small>Todos los niveles</small><b>No-Gi</b><span>Seis clases por semana</span></div></a>
      <a class="pcard" href="/womens/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-womens-1.webp" alt="" loading="lazy" width="640" height="665"><div class="pin"><small>Solo mujeres</small><b>Mujeres</b><span>Instructora cinturón negro</span></div></a>
      <a class="pcard" href="/kids/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/kids-run.webp" alt="" loading="lazy" width="1800" height="1200"><div class="pin"><small>3 a 12 años</small><b>Niños · Eagles</b><span>Cuatro grupos por edad</span></div></a>
      <a class="pcard" href="/kids/#teens"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-kids-coach.webp" alt="" loading="lazy" width="640" height="1136"><div class="pin"><small>13 a 16 años</small><b>Adolescentes</b><span>Mar y Jue 5 pm</span></div></a>
      <a class="pcard" href="/programs/#advanced"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-nogi-win.webp" alt="" loading="lazy" width="901" height="1496"><div class="pin"><small>Cinturón azul en adelante</small><b>Avanzado y competición</b><span>La sala de Cobrinha</span></div></a>
      <a class="pcard" href="/programs/#private"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/cobrinha.webp" alt="" loading="lazy" width="500" height="749"><div class="pin"><small>Uno a uno</small><b>Clases privadas</b><span>Instructores cinturón negro y marrón</span></div></a>
    </div>
  </div>
</section>


<section class="dark">
  <div class="wrap split rev">
    <div class="media tall rv r"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/cobrinha.webp" alt="Rubens Cobrinha Charles con su gi de Alliance, brazos cruzados, sonriendo" loading="lazy" width="500" height="749"></div>
    <div class="rv l">
      <p class="eyebrow light">Instructor principal</p>
      <h2 class="display">Rubens "Cobrinha" Charles</h2>
      <p class="lead">El único cinturón negro de la historia en ganar ADCC, el Mundial, el Panamericano, el Europeo y el Brasileño en un mismo año. Enseña en este tatami cada semana, y enseña a principiantes.</p>
      <ul class="titles">
        <li><b>5×</b><span>Campeón Mundial IBJJF (2006–2009, 2017)</span></li>
        <li><b>4×</b><span>Campeón Mundial No-Gi IBJJF</span></li>
        <li><b>3×</b><span>Campeón Mundial ADCC (2013, 2015, 2017)</span></li>
        <li><b>HOF</b><span>Salón de la Fama IBJJF y ADCC</span></li>
      </ul>
      <a class="btn ghost" href="/instructors/" style="margin-top:14px">Conoce a los instructores</a>
    </div>
  </div>
</section>

<section class="mat">
  <div class="wrap">
    <p class="eyebrow rv">Más</p>
    <h2 class="display rv">Todo lo demás, a un toque.</h2>
    <div class="explore rv">
      <a href="/start/"><b>Tu primer mes</b><span>Cómo son las primeras cuatro semanas, paso a paso.</span></a>
      <a href="/kids/"><b>Niños</b><span>De 3 a 16 años, por grupo de edad, con los horarios de la clase de prueba gratis.</span></a>
      <a href="/pricing/"><b>Membresía</b><span>8, 12 o clases ilimitadas al mes, y el plan familiar.</span></a>
      <a href="/visit/"><b>Visítanos</b><span>4929 Wilshire: estacionamiento, qué traer, qué pasa al entrar.</span></a>
      <a href="/faq/"><b>Preguntas</b><span>Respuestas directas a todo lo que se pregunta antes de la primera clase.</span></a>
    </div>
  </div>
</section>



<!-- /wp:html -->
