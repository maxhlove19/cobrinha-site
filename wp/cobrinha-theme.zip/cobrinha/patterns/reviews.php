<?php
/**
 * Title: What students say
 * Slug: cobrinha/reviews
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="phero">
  <div class="wrap">
    <p class="crumbs"><a href="/">Home</a> / What students say</p>
    <p class="eyebrow">Reviews</p>
    <h1 class="display">What students say.</h1>
    <p class="lead">Every quote here is a real review, and each one links to where it was written.</p>
  </div>
</section>
<section>
  <div class="wrap">
    <div class="sec-head rv">
      <h2 class="display">Rated 4.9 on Google.</h2>
    </div>
    <div class="rating rv">
      <b>4.9</b>
      <div><div class="stars" aria-label="4.9 out of 5 stars">★★★★★</div><div class="src">From 200 Google reviews · 4.7 on Yelp (120 reviews)</div></div>
      <a class="btn line" href="https://search.google.com/local/reviews?placeid=ChIJ9a1UHee4woARhGUPe_kWVfw" target="_blank" rel="noopener">Read the reviews</a>
    </div>
    <div class="grid-4 rv stagger">
      <div class="revcard"><p>"They literally remember each student's name and welcome each one of us to class each day. Cobrinha and the instructors have created a training environment based on kindness, respect, hard work and world-class instruction."</p><footer>Google review · adult member</footer></div>
      <div class="revcard"><p>"The quality of instruction is absolutely second to none. The fundamentals class had 34 students with four instructors in addition to Cobrinha himself. Jiu jitsu at its very best."</p><footer>Google review · visiting black belt</footer></div>
      <div class="revcard"><p>"Not only can you level up your jiu jitsu game, you can level up your character. In my opinion, it is the best place you could bring your son or daughter to learn."</p><footer>Google review · parent</footer></div>
      <div class="revcard"><p>"Cobrinha himself stayed behind after class to answer technical questions from everyone, including the visitors. A friendly and welcoming environment with great training partners."</p><footer>Google review · visitor</footer></div>
    </div>
    <p class="muted rv small" style="margin-top:18px">Quotes are taken word for word from public Google reviews. Names are shown once each reviewer confirms.</p>
  </div>
</section>
<!-- /wp:html -->
