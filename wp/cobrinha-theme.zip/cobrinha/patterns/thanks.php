<?php
/**
 * Title: Got it
 * Slug: cobrinha/thanks
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="phero">
  <div class="wrap">
    <p class="eyebrow">Request received</p>
    <h1 class="display">See you on the mat.</h1>
    <p class="lead">We'll text or email you to confirm the time, usually within the hour during class hours. If you'd rather not wait, call <a class="link" href="tel:+13239319953">(323) 931-9953</a>.</p>
  </div>
</section>
<section>
  <div class="wrap grid-2">
    <div class="rv l">
      <p class="eyebrow">Before you come</p>
      <ul class="checks">
        <li>Arrive 15 minutes early and <a class="link" href="https://cobrinha-jiu-jitsu-academy.gymdesk.com/signup" target="_blank" rel="noopener">sign the waiver online</a> to save time at the desk.</li>
        <li>Wear comfortable athletic clothes. Gi rental is $20 for adults, $15 for kids, refunded in full when you sign up.</li>
        <li>Park in the building lot with validation, or free on Highland Ave. <a class="link" href="/visit/">Parking details</a>.</li>
        <li>Bring water. Flip-flops for the walk between the changing room and the mat.</li>
      </ul>
    </div>
    <div class="rv r">
      <p class="eyebrow">While you wait</p>
      <p><a class="link" href="/start/">What your first class looks like, minute by minute</a></p>
      <p><a class="link" href="/schedule/">The full weekly schedule</a></p>
      <p><a class="link" href="/faq/">Questions and answers</a></p>
      <p><a class="link" href="/instructors/">The instructors you'll meet</a></p>
    </div>
  </div>
</section>

<!-- /wp:html -->
