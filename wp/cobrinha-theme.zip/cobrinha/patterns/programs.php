<?php
/**
 * Title: Programs
 * Slug: cobrinha/programs
 * Categories: cobrinha
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="phero">
  <div class="wrap">
    <p class="crumbs"><a href="/">Home</a> / Programs</p>
    <p class="eyebrow">Programs</p>
    <h1 class="display">A class for where you are.</h1>
    <p class="lead">Every program has its own slots on the schedule, so beginners train with beginners and blue belts train with Cobrinha. You never have to guess which class is yours.</p>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="prog rv stagger">
      <a class="pcard" href="/start/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/beginners.webp" alt="" loading="lazy"><div class="pin"><small>Adults · no experience</small><b>Beginners</b><span>Four-week course</span></div></a>
      <a class="pcard" href="#fundamentals"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-fundamentals.webp" alt="" loading="lazy"><div class="pin"><small>Adults</small><b>Fundamentals</b><span>Levels 1, 2, 3</span></div></a>
      <a class="pcard" href="#advanced"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-nogi-win.webp" alt="" loading="lazy"><div class="pin"><small>Blue belt and up</small><b>Advanced &amp; Competition</b><span>Cobrinha's room</span></div></a>
      <a class="pcard" href="#nogi"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-nogi-1.webp" alt="" loading="lazy"><div class="pin"><small>All levels</small><b>No-Gi</b><span>Six classes a week</span></div></a>
      <a class="pcard" href="/womens/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-womens-1.webp" alt="" loading="lazy"><div class="pin"><small>Women only</small><b>Women's</b><span>Black belt coach</span></div></a>
      <a class="pcard" href="/kids/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/kids-run.webp" alt="" loading="lazy"><div class="pin"><small>Ages 3–12</small><b>Kids · Eagles</b><span>Four age groups</span></div></a>
      <a class="pcard" href="/kids/#teens"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-kids-coach.webp" alt="" loading="lazy"><div class="pin"><small>Ages 13–16</small><b>Teens</b><span>Tue &amp; Thu 5 pm</span></div></a>
      <a class="pcard" href="#private"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/cobrinha.webp" alt="" loading="lazy"><div class="pin"><small>One on one</small><b>Private lessons</b><span>Black and brown belt instructors</span></div></a>
    </div>
  </div>
</section>

<section class="mat" id="fundamentals">
  <div class="wrap split">
    <div class="rv">
      <p class="eyebrow">Adults</p>
      <h2 class="display">Fundamentals 1, 2 and 3.</h2>
      <p class="lead">The core of the academy. After the beginners course you join Fundamentals 1 and work through the positions, escapes, sweeps, passes and submissions that every black belt still drills. Stripes move you to Fundamentals 2 (three stripes) and 3 (four stripes).</p>
      <ul class="checks">
        <li>Fundamentals 1: Mon &amp; Wed 8 pm, Tue &amp; Thu 6:10 pm, Tue 6:30 am</li>
        <li>Fundamentals 2: Mon &amp; Wed 6:30 am, Mon &amp; Wed 6:10 pm, Fri 6:20 pm</li>
        <li>Fundamentals 3: Saturday 11:15 am · All Levels: Tue &amp; Thu 6:30 am</li>
        <li>Everyone trains in a blue or white Alliance or Cobrinha gi with a rash guard underneath; one team, one look</li>
      </ul>
      <a class="btn red" href="/free-class/">Book a free class</a>
    </div>
    <div class="media tall rv r"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-fundamentals.webp" alt="Fundamentals class: an instructor demonstrates a sweep" loading="lazy"></div>
  </div>
</section>

<section id="advanced">
  <div class="wrap split rev">
    <div class="media wide rv l"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/hero-mat-wide.webp" alt="The advanced class seated on the mat with Cobrinha" loading="lazy"></div>
    <div class="rv">
      <p class="eyebrow">Blue belt and above</p>
      <h2 class="display">Advanced &amp; Competition.</h2>
      <p class="lead">Ninety-minute classes taught by Cobrinha and his black belts: the systems that won five World titles, broken down and drilled, then sparred. Competition preparation runs inside this room for anyone who wants to test themselves, from local opens to the Worlds.</p>
      <ul class="checks">
        <li>Mon &amp; Wed 7:20 pm · Mon, Wed &amp; Fri 12:00 pm</li>
        <li>No-Gi Advanced: Tue &amp; Thu 12:00 pm</li>
        <li>Visiting blue belts and up are welcome; call ahead. Drop-in $60 with gi included, refunded if you sign up</li>
      </ul>
    </div>
  </div>
</section>

<section class="mat" id="nogi">
  <div class="wrap split">
    <div class="rv">
      <p class="eyebrow">All levels</p>
      <h2 class="display">No-Gi.</h2>
      <p class="lead">Submission grappling without the kimono: faster, wrestling-heavy, and the base of modern MMA grappling. Six No-Gi classes a week, all on Tuesday and Thursday. No-Gi Fundamentals is open to everyone; the 7:20 class is for white belts with three stripes and up.</p>
      <ul class="checks">
        <li>Tue &amp; Thu 12:00 pm: No-Gi Advanced (blue belt and up)</li>
        <li>Tue &amp; Thu 6:10 pm: No-Gi Fundamentals (or Gi Fundamentals 1 in the same slot)</li>
        <li>Tue &amp; Thu 7:20 pm: No-Gi (white belt three stripes and up)</li>
        <li>Academy ranked rash guard and black shorts</li>
      </ul>
      <a class="btn red" href="/free-class/">Try a class free</a>
    </div>
    <div class="media tall rv r"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-nogi-medals.webp" alt="Two academy competitors with medals at the San Diego Open" loading="lazy"></div>
  </div>
</section>

<section id="womens">
  <div class="wrap split rev">
    <div class="media tall rv l"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/ig-womens-2.webp" alt="Women's class: Ursula coaching a technique while the class watches" loading="lazy"></div>
    <div class="rv">
      <p class="eyebrow">Women only</p>
      <h2 class="display">Women's program.</h2>
      <p class="lead">A class created for women to get stronger, learn real self-defense and build confidence with people who understand what that takes. Taught by Ursula, a female black belt. No experience needed and all levels train together.</p>
      <ul class="checks">
        <li>Tuesday 8:00 am · Saturday 11:15 am</li>
        <li>Free trial: Wednesday 6:10 pm is the best slot; Tuesday or Thursday 6:10 pm also work</li>
        <li>Self-defense focus, supportive room, women's changing room and showers</li>
      </ul>
      <a class="btn red" href="free-class.html?program=womens">Book the women's free trial</a> <a class="btn line" href="/womens/">The women's program</a>
    </div>
  </div>
</section>

<section class="mat" id="private">
  <div class="wrap split">
    <div class="rv">
      <p class="eyebrow">One on one</p>
      <h2 class="display">Private lessons.</h2>
      <p class="lead">The fastest way to fix one thing. Sixty minutes with a brown or black belt on exactly what you need: a position, competition prep, a comeback after injury, or a flexible schedule. All privates are booked in advance with the instructor.</p>
      <div class="strip">
        <div class="srow"><b>Brown belt · 60 min</b><span>Single lessons or packs of 5 and 10</span></div>
        <div class="srow"><b>Black belt · 60 min</b><span>Single lessons or packs of 5 and 10</span></div>
        <div class="srow"><b>Small group of 4</b><span>Split the lesson with training partners</span></div>
        <div class="srow"><b>With Cobrinha</b><span>By request</span></div>
      </div>
      <p class="small muted">Changes and cancellations go through your instructor. A no-show uses the lesson.</p>
      <a class="btn red" href="/contact/">Ask about privates</a>
    </div>
    <div class="media tall rv r"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/cobrinha.webp" alt="Cobrinha" loading="lazy"></div>
  </div>
</section>

<!-- /wp:html -->
